#Normalization codes
Normalize <- function(counts, conditions, norm.method="QN", seed=123, B=20)
{
  #Normalization of count matrix
  
  if(norm.method=="QN"){
    #Quantile Normalization
    require(preprocessCore)
    norm.counts <- normalize.quantiles(as.matrix(counts))
    
    colnames(norm.counts) <- colnames(counts)
    rownames(norm.counts) <- rownames(counts)
    return(norm.counts)
  }
  else if(norm.method=="limmaQN"){
    #Quantile Normalization
    require(limma)
    counts.log.dat=log2(counts+0.5)
    norm.counts=normalizeBetweenArrays(counts.log.dat, method='quantile')
    
    colnames(norm.counts) <- colnames(counts)
    return(norm.counts)
  }
  
  else if(norm.method=="TMM"){
    
    #TMM Normalization
    # require(edgeR)
    # y <- DGEList(counts=counts, group=conditions)
    # y <- calcNormFactors(y)
    # y <- estimateCommonDisp(y) 
    # 
    # norm.counts <- y$pseudo.counts
    # 
    # #LS <- apply(counts, 2, sum)
    # #v = calcNormFactors(y, method="TMM")$samples[,3]*LS
    # 
    # #norm.counts <- matrix(NA, ncol=ncol(counts), nrow=nrow(counts))
    # #for(i in 1:ncol(counts)){
    # #  norm.counts[, i] <- counts[,i]/v[i]*1e6
    # #}
    # 
    # colnames(norm.counts) <- colnames(counts)    
    # return(norm.counts)
    
    
    require(edgeR)
    y <- DGEList(counts=counts, group= rep(1, ncol(counts)))
    
    ## estimate size factor
    y       <- calcNormFactors(y)
    tmm.factors <- y$samples$norm.factors
    norm.lib.size <- colSums(counts)*tmm.factors
    factors <-  mean(norm.lib.size)/norm.lib.size
    norm.counts <- counts%*%diag(factors)
    
    colnames(norm.counts) <- colnames(counts)
    return(norm.counts)
  }
  
  #DESeq Normalization
  else if(norm.method=="DESeq"){
    require(DESeq)
    cds <- newCountDataSet(counts, conditions)
    
    ## estimate size factor
    cds <- estimateSizeFactors(cds)
    norm.counts <- counts(cds, normalized=TRUE)
    
    colnames(norm.counts) <- colnames(counts)
    return(norm.counts)
  }
  
  #PoissonSeq normalization
  else if(norm.method=="PoissonSeq"){
    require(PoissonSeq)
    
    seq.depth <- PS.Est.Depth(counts, ct.sum=1, ct.mean=0)
    norm.counts <- counts
    for(i in 1:ncol(counts)){
      norm.counts[,i] <- counts[,i]/seq.depth[i]
    }
    
    colnames(norm.counts) <- colnames(counts)
    return(norm.counts)
  }
  
  
  else if(norm.method=="SAMSeq"){
    require(samr)
    require(psych)
    
    x <- counts
    y <- ifelse(conditions=="condA",1,2)
    samfit <- SAMseq(x, y, geneid=rownames(counts), resp.type="Two class unpaired", fdr.output=1.0)

    ls <-apply(counts, 2, sum)
    depth <- samfit$samr.obj$depth

    gm <- geometric.mean(depth)
    factor <- gm/depth
    
    norm.counts <- counts
    for(i in 1:ncol(counts)){
      for(j in 1:nrow(counts)){
        set.seed(seed)
        norm.counts[j,i] <- mean(rpois(B, counts[j,i]*factor[i]))
      }
    }
    
    #factors <- diag(gm/depth)
    #norm.counts <- as.matrix(x)%*%factors
    colnames(norm.counts) <- colnames(counts)
    return(norm.counts)
    
  }
}


#Function to calculate gene-wise group specific coefficients of variations
CV <- function(counts, group){
  #A function that computes gene wise group specific CV
  group=as.factor(group)  
  CV <- apply(counts, 1, function(x) {
    c(sd(x[group==levels(group)[1]])/mean(x[group==levels(group)[1]]), 
      sd(x[group==levels(group)[2]])/mean(x[group==levels(group)[2]]))
  })   
  CV <- as.data.frame(t(CV))
  colnames(CV) <- levels(group)
  return(CV)
}

#A function to sort levels by variable
# source https://github.com/janhove/janhove.github.io/blob/master/RCode/sortLvls.R
sortLvlsByVar.fnc <- function(oldFactor, sortingVariable, ascending = TRUE) {
  
  require("dplyr")
  require("magrittr")
  
  # Combine into data frame
  df <- data.frame(oldFactor, sortingVariable)
  
  ###
  ### If you want to sort the levels by, say, the median, sd etc. instead of the mean,
  ### just change 'mean(sortingVariable)' below to, say, 'median(sortingVariable)'.
  ###
  
  # Compute average of sortingVariable and arrange (ascending)
  if (ascending == TRUE) {
    df_av <- df %>% group_by(oldFactor) %>% summarise(meanSortingVariable = median(sortingVariable)) %>% 
      arrange(meanSortingVariable)
  }
  
  # Compute average of sortingVariable and arrange (descending)
  if (ascending == FALSE) {
    df_av <- df %>% group_by(oldFactor) %>% summarise(meanSortingVariable = median(sortingVariable)) %>% 
      arrange(desc(meanSortingVariable))
  }
  
  # Return factor with new level order
  newFactor <- factor(oldFactor, levels = df_av$oldFactor)
  return(newFactor)
}


#Wilcoxon rank sum test
WMW.test<- function(counts, group, alpha=0.05)
{ 
  result<- data.frame(pval =sapply(1:nrow(counts), function(i) {
    return(wilcox.test(counts[i,]~group)$p.value)
  }))
  
  result$Genes <- rownames(counts)
  result$adjp <- p.adjust(result$pval, method = "BH")
  result$class <- ifelse(result$pval < alpha, 1, 0) 
  return(result)
}

#Moderated t.tetst
limma.test <- function(counts, group, alpha=0.05){
  require(limma)
  # Create model matrix and set up dge object
  design <- model.matrix(~group)
  # Quantile normalization  
  #counts.log.dat=log2(counts+0.5)
  #counts.log.dat=normalizeBetweenArrays(counts.log.dat, method='none')
  
  # Test for differential expression
  fit <- lmFit(counts, design)
  fit <- eBayes(fit)
  
  # Return top table
  de_table <- topTable(fit, coef=ncol(design), n=nrow(counts), sort.by="none")
  res <- as.data.frame(de_table)
  res$Genes <- rownames(res)
  res <- res[,c(1,2,4,5,7)]
  colnames(res) <- c("LFC", "Mean", "pval", "adjp", "Genes")
  res$adjp[is.na(res$adjp)] <- 1
  res$class <- ifelse(res$adjp<alpha, 1, 0)
  return(res)
}


#A function to calculate overlap proportion or count
calc.overlap <- function(x, y, prop=TRUE){ 
  if(length(x)!=length(y)){ stop("x and y have different length!")}
  stopifnot(unique(x) %in% c(0,1))
  stopifnot(unique(y) %in% c(0,1))
  
  if(sum(x+y>=1)>0){
    if(prop) {sum(x+y==2)/sum(x+y>=1)}
    else{sum(x+y==2)}
  }
  else {0}
  
}