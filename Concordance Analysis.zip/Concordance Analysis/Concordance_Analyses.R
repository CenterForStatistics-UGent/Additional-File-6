
rm(list = ls())


#Loading required packages
#install.packages("devtools")
library(reshape2)
library(ggplot2)
library(corrplot) 
library(Hmisc) 
library(gplots)
library(ape)

#Summary of comparison metrics from concordance analysis 
dir1 <- "C:/Users/Alemu/Desktop/Additional File 6/Concordance Analysis/"

#---------------------------------------------------------------------------
#Number of SDE genes at 5% FDR 
CRC_AZA.SDE <- readRDS(paste0(dir1,"CRC_AZA\\SDE.summary.RData"))
CRC_AZA.SDE <-CRC_AZA.SDE[[1]]

Hammer.SDE <- readRDS(paste0(dir1,"Hammer\\SDE.summary.RData"))
Hammer.SDE <- Hammer.SDE[[1]]

Bottomly.SDE <- readRDS(paste0(dir1,"Bottomly\\SDE.summary.RData"))
Bottomly.SDE <- Bottomly.SDE[[1]]

GTEx.SDE <- readRDS(paste0(dir1,"GTEx\\SDE.summary.RData"))
GTEx.SDE <- GTEx.SDE[[1]]

Zhang.SDE <- readRDS(paste0(dir1, "Zhang\\SDE.summary.RData"))
Zhang.SDE <- Zhang.SDE[[2]]
Zhang.mRNA.SDE <- Zhang.SDE[Zhang.SDE$biotype=="mRNA", -2]
Zhang.lncRNA.SDE <- Zhang.SDE[Zhang.SDE$biotype=="lncRNA", -2]

NGP.SDE <- readRDS(paste0(dir1, "NGP Nutlin\\SDE.summary.RData"))
NGP.SDE <- NGP.SDE[[2]]
NGP.mRNA.SDE <- NGP.SDE[NGP.SDE$biotype=="mRNA", -2]
NGP.lncRNA.SDE <- NGP.SDE[NGP.SDE$biotype=="lncRNA", -2]


all.SDE <- cbind(CRC_AZA.SDE, Hammer.SDE$DE, Bottomly.SDE$DE, GTEx.SDE$DE, 
                 Zhang.mRNA.SDE$DE, Zhang.lncRNA.SDE$DE, NGP.mRNA.SDE$DE,  NGP.lncRNA.SDE$DE)
colnames(all.SDE) <- c("Methods", "CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang (mRNA)", "Zhang (lncRNA)",
                       "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")
N.CRC_AZA <- 14658; N.Hammer <- 15908 ; N.Bottomly <- 12784
N.GTEx <- 18632; N.Zhang.mRNA <- 19254 ; N.Zhang.lncRNA <-  10051
N.NGP.mRNA <- 17489 ; N.NGP.lncRNA <- 8929 
N <- c(N.CRC_AZA, N.Hammer, N.Bottomly, N.GTEx, N.Zhang.mRNA, N.Zhang.lncRNA, N.NGP.mRNA, N.NGP.lncRNA)

rownames(all.SDE) <- all.SDE$Methods
all.SDE$Methods<-NULL
all.SDE.prop <- as.matrix(all.SDE)%*%diag(1/N)
colnames(all.SDE.prop) <- c("CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang (mRNA)", "Zhang (lncRNA)",
                            "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")

#Overlap between DE tools at 5% FDR 
CRC_AZA.mean.overlap <- readRDS(paste0(dir1,"CRC_AZA\\mean.overlap.prop.RData"))

Hammer.mean.overlap <- readRDS(paste0(dir1,"Hammer\\mean.overlap.prop.RData")) 

Bottomly.mean.overlap <- readRDS(paste0(dir1,"Bottomly\\mean.overlap.prop.RData")) 

GTEx.mean.overlap <- readRDS(paste0(dir1,"GTEx\\mean.overlap.prop.RData")) 

Zhang.mean.overlap.mRNA <- readRDS(paste0(dir1, "Zhang\\mean.overlap.prop.mRNA.RData"))
Zhang.mean.overlap.lncRNA <- readRDS(paste0(dir1, "Zhang\\mean.overlap.prop.lncRNA.RData"))

NGP.mean.overlap.mRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.overlap.prop.mRNA.RData"))
NGP.mean.overlap.lncRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.overlap.prop.lncRNA.RData"))


all.mean.overlap.prop <-data.frame(CRC_AZA.mean.overlap, Hammer.mean.overlap, Bottomly.mean.overlap, GTEx.mean.overlap, 
                                   Zhang.mean.overlap.mRNA, Zhang.mean.overlap.lncRNA, 
                                   NGP.mean.overlap.mRNA, NGP.mean.overlap.lncRNA)
colnames(all.mean.overlap.prop) <- c("CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang (mRNA)", "Zhang (lncRNA)",
                                     "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")


#Mean Gene Ranking correlation 
CRC_AZA.mean.rank.cor <- readRDS(paste0(dir1,"CRC_AZA\\mean.rank.cor.RData")) 

Hammer.mean.rank.cor <- readRDS(paste0(dir1,"Hammer\\mean.rank.cor.RData")) 

Bottomly.mean.rank.cor <- readRDS(paste0(dir1,"Bottomly\\mean.rank.cor.RData")) 

GTEx.mean.rank.cor <- readRDS(paste0(dir1,"GTEx\\mean.rank.cor.RData")) 

Zhang.mean.rank.cor.mRNA <- readRDS(paste0(dir1, "Zhang\\mean.rank.cor.mRNA.RData"))
Zhang.mean.rank.cor.lncRNA <- readRDS(paste0(dir1, "Zhang\\mean.rank.cor.lncRNA.RData"))

NGP.mean.rank.cor.mRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.rank.cor.mRNA.RData"))
NGP.mean.rank.cor.lncRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.rank.cor.lncRNA.RData"))

all.mean.rank.cor <- data.frame(CRC_AZA.mean.rank.cor, Hammer.mean.rank.cor, Bottomly.mean.rank.cor, GTEx.mean.rank.cor, 
                                Zhang.mean.rank.cor.mRNA, Zhang.mean.rank.cor.lncRNA,
                                NGP.mean.rank.cor.mRNA, NGP.mean.rank.cor.lncRNA)
colnames(all.mean.rank.cor) <- c("CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang (mRNA)", "Zhang (lncRNA)",
                                 "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")



#Mean LFC correlation summary 
CRC_AZA.mean.lfc.cor <- readRDS(paste0(dir1,"CRC_AZA\\mean.lfc.cor.RData")) 

Hammer.mean.lfc.cor <- readRDS(paste0(dir1,"Hammer\\mean.lfc.cor.RData")) 

Bottomly.mean.lfc.cor <- readRDS(paste0(dir1,"Bottomly\\mean.lfc.cor.RData")) 

GTEx.mean.lfc.cor <- readRDS(paste0(dir1,"GTEx\\mean.lfc.cor.RData")) 

Zhang.mean.lfc.cor.mRNA <- readRDS(paste0(dir1, "Zhang\\mean.lfc.cor.mRNA.RData"))
Zhang.mean.lfc.cor.lncRNA <- readRDS(paste0(dir1, "Zhang\\mean.lfc.cor.lncRNA.RData"))

NGP.mean.lfc.cor.mRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.lfc.cor.mRNA.RData"))
NGP.mean.lfc.cor.lncRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.lfc.cor.lncRNA.RData"))

all.mean.lfc.cor <- data.frame(CRC_AZA.mean.lfc.cor, Hammer.mean.lfc.cor, Bottomly.mean.lfc.cor, GTEx.mean.lfc.cor, 
                               Zhang.mean.lfc.cor.mRNA, Zhang.mean.lfc.cor.lncRNA,
                               NGP.mean.lfc.cor.mRNA, NGP.mean.lfc.cor.lncRNA)

colnames(all.mean.lfc.cor) <- c("CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang (mRNA)", "Zhang (lncRNA)",
                                "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")



#Comuptation time summary 
CRC_AZA.comp.time <- readRDS(paste0(dir1, "CRC_AZA\\comput.time.RData"))
Hammer.comp.time <- readRDS(paste0(dir1, "Hammer\\comput.time.RData"))
Bottomly.comp.time <- readRDS(paste0(dir1, "Bottomly\\comput.time.RData"))
GTEx.comp.time <- readRDS(paste0(dir1, "GTEx\\comput.time.RData"))
Zhang.comp.time <- readRDS(paste0(dir1, "Zhang\\comput.time.RData"))
NGP.comp.time <- readRDS(paste0(dir1, "NGP Nutlin\\comput.time.RData"))

all.comput.time <- data.frame(CRC_AZA.comp.time, Hammer.comp.time, Bottomly.comp.time,
                              GTEx.comp.time, Zhang.comp.time,  NGP.comp.time)
colnames(all.comput.time) <- c("CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang", "NGP Nutlin")
all.inv.comput.time.log <- log(1/all.comput.time)
log.inv.comp.time.z_scores <- apply(all.inv.comput.time.log, 2, function(x) (x-mean(x))/sd(x))



#--------------------------------------------------------------------------------------------
#Hierarchical clustering of DE tools for each comparison metrics, across datsest
  #Proportion of SDE genes
  SDE.prop.summary <- data.frame(CRC_AZA    = all.SDE.prop[rownames(all.SDE.prop), "CRC AZA"],
                                 Hammer      = all.SDE.prop[rownames(all.SDE.prop), "Hammer"],
                                 Bottomly    = all.SDE.prop[rownames(all.SDE.prop), "Bottomly"],
                                 GTEx        = all.SDE.prop[rownames(all.SDE.prop), "GTEx"],
                                 Zhang.mRNA  = all.SDE.prop[rownames(all.SDE.prop), "Zhang (mRNA)"],
                                 Zhang.lncRNA= all.SDE.prop[rownames(all.SDE.prop), "Zhang (lncRNA)"],
                                 NGP.mRNA  = all.SDE.prop[rownames(all.SDE.prop), "NGP Nutlin (mRNA)"],
                                 NGP.lncRNA= all.SDE.prop[rownames(all.SDE.prop), "NGP Nutlin (lncRNA)"],
                                 row.names = rownames(all.SDE.prop))
  SDE.prop.summary.z_score <- apply(SDE.prop.summary, 2, function(x) (x - mean(x))/sd(x))
  mean.z_score.SDE <- sort(apply(SDE.prop.summary.z_score, 1, mean))
  
  
  #Proportion of overlap
  overlap.prop.summary <- data.frame(CRC_AZA = all.mean.overlap.prop[rownames(all.SDE.prop), "CRC AZA"],
                                     Hammer      = all.mean.overlap.prop[rownames(all.SDE.prop), "Hammer"],
                                     Bottomly    = all.mean.overlap.prop[rownames(all.SDE.prop), "Bottomly"],
                                     GTEx        = all.mean.overlap.prop[rownames(all.SDE.prop), "GTEx"],
                                     Zhang.mRNA  = all.mean.overlap.prop[rownames(all.SDE.prop), "Zhang (mRNA)"],
                                     Zhang.lncRNA= all.mean.overlap.prop[rownames(all.SDE.prop), "Zhang (lncRNA)"],
                                     NGP.mRNA  = all.mean.overlap.prop[rownames(all.SDE.prop), "NGP Nutlin (mRNA)"],
                                     NGP.lncRNA= all.mean.overlap.prop[rownames(all.SDE.prop), "NGP Nutlin (lncRNA)"],
                                     row.names = rownames(all.SDE.prop))
  overlap.prop.summary.z_score <- apply(overlap.prop.summary, 2,  function(x) (x - mean(x))/sd(x))
  mean.z_score.overlap <- sort(apply(overlap.prop.summary.z_score, 1, mean))
  
  
  #Mean gene ranking agreement 
  rank.correlation.summary <- data.frame(CRC_AZA = all.mean.rank.cor[rownames(all.SDE.prop), "CRC AZA"],
                                         Hammer      = all.mean.rank.cor[rownames(all.SDE.prop), "Hammer"],
                                         Bottomly    = all.mean.rank.cor[rownames(all.SDE.prop), "Bottomly"],
                                         GTEx        = all.mean.rank.cor[rownames(all.SDE.prop), "GTEx"],
                                         Zhang.mRNA  = all.mean.rank.cor[rownames(all.SDE.prop), "Zhang (mRNA)"],
                                         Zhang.lncRNA= all.mean.rank.cor[rownames(all.SDE.prop), "Zhang (lncRNA)"],
                                         NGP.mRNA  = all.mean.rank.cor[rownames(all.SDE.prop), "NGP Nutlin (mRNA)"],
                                         NGP.lncRNA= all.mean.rank.cor[rownames(all.SDE.prop), "NGP Nutlin (lncRNA)"],
                                         row.names = rownames(all.SDE.prop))
  rank.correlation.summary.z_score <- apply(rank.correlation.summary, 2, function(x) (x - mean(x))/sd(x))
  mean.z_score.cor.rank <- sort(apply(rank.correlation.summary.z_score, 1, mean))
  
  
  #Mean LFC correlation 
  lfc.correlation.summary <- data.frame(CRC_AZA      = all.mean.lfc.cor[rownames(all.SDE.prop), "CRC AZA"],
                                        Hammer      = all.mean.lfc.cor[rownames(all.SDE.prop), "Hammer"],
                                        Bottomly    = all.mean.lfc.cor[rownames(all.SDE.prop), "Bottomly"],
                                        GTEx        = all.mean.lfc.cor[rownames(all.SDE.prop), "GTEx"],
                                        Zhang.mRNA  = all.mean.lfc.cor[rownames(all.SDE.prop), "Zhang (mRNA)"],
                                        Zhang.lncRNA= all.mean.lfc.cor[rownames(all.SDE.prop), "Zhang (lncRNA)"],
                                        NGP.mRNA  = all.mean.lfc.cor[rownames(all.SDE.prop), "NGP Nutlin (mRNA)"],
                                        NGP.lncRNA= all.mean.lfc.cor[rownames(all.SDE.prop), "NGP Nutlin (lncRNA)"],
                                        row.names = rownames(all.SDE.prop))
  lfc.correlation.summary <- lfc.correlation.summary[-c(21),]
  lfc.correlation.summary.z_score <- apply(lfc.correlation.summary, 2, function(x) (x - mean(x))/sd(x))
  
  #Computation time
  run.time.summary <- data.frame(CRC_AZA     = all.comput.time[rownames(all.SDE.prop), "CRC AZA"],
                                 Hammer      = all.comput.time[rownames(all.SDE.prop), "Hammer"],
                                 Bottomly    = all.comput.time[rownames(all.SDE.prop), "Bottomly"],
                                 GTEx        = all.comput.time[rownames(all.SDE.prop), "GTEx"],
                                 Zhang       = all.comput.time[rownames(all.SDE.prop), "Zhang"],
                                 NGP         = all.comput.time[rownames(all.SDE.prop), "NGP Nutlin"],
                                 row.names = rownames(all.SDE.prop)) 
  run.time.summary.z_score <- apply(run.time.summary, 2, function(x) (x - mean(x))/sd(x))

  
  
#Hierarchical clustering of DE tools avaraged over datasets

  Z_scores.DE <- data.frame(SDE.prop = rowMeans(SDE.prop.summary.z_score)[rownames(all.SDE.prop)],
                            mean.overlap = rowMeans(overlap.prop.summary.z_score)[rownames(all.SDE.prop)],
                            mean.gene.rank.cor = rowMeans(rank.correlation.summary.z_score)[rownames(all.SDE.prop)],
                            mean.LFC.cor = rowMeans(lfc.correlation.summary.z_score)[rownames(all.SDE.prop)],
                            mean.inv.comp.time = rowMeans(run.time.summary)[rownames(all.SDE.prop)])
  
  Z_scores.DE.sel <- Z_scores.DE[,c(1,2,3,4)]
  temp.names <- sapply(rownames(Z_scores.DE.sel), function(x){
    if(x=="DESeq2 (indFilt=OFF, CooksCut=OFF)"){"DESeq2 (setting1)"}
    else if(x=="DESeq2 (indFilt=OFF)"){"DESeq2 (setting2)"}
    else if(x=="DESeq2 (indFilt=ON)"){"DESeq2 (default)"}
    else{x}
  }, USE.NAMES = FALSE)
  rownames(Z_scores.DE.sel) <- temp.names
  
  
  
  win.graph()
  # Dissimilarity matrix
  d <- dist(Z_scores.DE.sel)
  res.hc <- hclust(d, method = "ward.D2" ) # Hierarchical clustering using Ward's method
  plot(res.hc, col = "black", col.main = "gray20", col.lab = "gray30", main="",
       col.axis = "gray40", lwd = 2, lty = 1, sub = "", hang = -1, axes = FALSE)
  rect.hclust(res.hc, k = 4, border = c("firebrick", "goldenrod3", "mediumseagreen"))
  axis(side = 2, at = seq(0, 5, 1), col = "gray50", labels = FALSE,  lwd = 1.75)
  # add text in margin
  mtext(seq(0, 5, 1), side = 2, at = seq(0, 5, 1), line = 1, lwd=1.5,
        col = "gray50", las = 2)
  
  #How the number of clusters are determined
  k.max <- 10# Maximal number of clusters
  data <- dist(Z_scores.DE.sel)
  wss <- sapply(1:k.max,
                function(k){kmeans(data, k, nstart=10 )$tot.withinss})
  plot(1:k.max, wss,
       type="b", pch = 19, frame = FALSE,
       xlab="Number of clusters K",
       ylab="Total within-clusters sum of squares")
  abline(v = 4, lty =2)
  
  
  
  choose.cols <- function(y, low=rgb(255,0,0, maxColorValue = 255),
                          high=rgb(0,0,225, maxColorValue = 255), 
                          rev=FALSE, reference=seq(-2.5, 2.5, 0.1)){
    
    if(rev){
      rank.reference <- rev(rank(reference))
    }
    else{ 
      rank.reference <- rank(reference) 
    }
    
    y <- round(y, 1)
    match.y.rank <- rank.reference[findInterval(y, reference)]
    
    cols = c(low,high)
    mypalette <- colorRampPalette(cols)(length(reference)) 
    cols <- mypalette[match.y.rank]
    cols
  }
  
  png("Figure3.png", width = 170, height = 160, units = 'mm', res = 300)
  par(mfrow=c(1,2))
  layout(matrix(c(1,2,2), nrow = 1, ncol =3, byrow = TRUE))
  par(mar=c(4,0,2,0)+0.1, xpd=FALSE)
  plot(seq(0,7.75, length.out = nrow(Z_scores.DE.sel)), 1:nrow(Z_scores.DE.sel), type="n", axes = FALSE,
       xlab="", ylab="", main = "")
  for(i in 1:nrow(Z_scores.DE.sel)){
    if(i%%2==0){polygon(x=c(0, 0, 7.75, 7.75), y=c(i-0.4, i+0.4, i+0.4, i-0.4), border = NA, col="gray95")}
    else{polygon(x=c(-2.5, -2.5, 2.5, 2.5), y=c(i-0.4, i+0.4, i+0.4, i-0.4), border = NA, col="gray98")}
  }
  par(new=TRUE)
  plot(as.phylo(res.hc), label.offset = 0.1, cex = 1.0, font=1,
       edge.color = "steelblue", edge.width = 2, edge.lty = 1,
       tip.color = "black", x.lim = c(0,8.5))
  
  #Adding clusters, based on number of clusters determined using kmeans (see the code above)
  polygon(x=c(2.0,2.0,8.85,8.85), y=c(0.6,4.4,4.4, 0.6), border="gray35", lty=2)
  polygon(x=c(2.0,2.0,8.85,8.85), y=c(4.6,7.4,7.4,4.6), border="gray35", lty=2)
  polygon(x=c(2.0,2.0,8.85,8.85), y=c(7.6,15.4,15.4, 7.6), border="gray35", lty=2)
  polygon(x=c(2.0,2.0,8.85,8.85), y=c(15.6,25.4,25.4, 15.6), border="gray35", lty=2)
  
  par(mar=c(4,0,2,0)+0.1, xpd=FALSE)
  plot(seq(-2.5, 19, length.out = nrow(Z_scores.DE.sel)), 1:nrow(Z_scores.DE.sel), type = "n", 
       axes=FALSE, xlab="standard score", ylab="", cex.lab=1.25)
  #abline(v=c(0, 5.5, 11, 16.5), col="gray")
  axis(1, at=c(-2.5, 0 , 2.5), labels = c(-2.5, 0 , 2.5), col="gray", las=2, cex=2)
  axis(1, at=c(3, 5.5, 8), labels = c(-2.5, 0 , 2.5),     col="gray", las=2)
  axis(1, at=c(8.5, 11, 13.5), labels = c(-2.5, 0 , 2.5), col="gray", las=2)
  axis(1, at=c(14, 16.5, 19), labels = c(-2.5, 0 , 2.5),  col="gray", las=2)
  mtext("A                     B                    C                    D", side=3)
  
  #number of SDE genes
  for(i in 1:nrow(Z_scores.DE.sel)){
    if(i%%2==0){polygon(x=c(-2.5, -2.5, 2.5, 2.5), y=c(i-0.4, i+0.4, i+0.4, i-0.4), border = NA, col="gray95")}
    else{polygon(x=c(-2.5, -2.5, 2.5, 2.5), y=c(i-0.4, i+0.4, i+0.4, i-0.4), border = NA, col="gray98")}
  }
  abline(v=0, col="gray")
  points(Z_scores.DE.sel[res.hc$order, 1], 1:nrow(Z_scores.DE.sel), pch=16, cex=1.25,
         col=choose.cols(Z_scores.DE.sel[res.hc$order, 1]))
  segments(Z_scores.DE.sel[res.hc$order, 1], 1:nrow(Z_scores.DE.sel), 
           0, 1:nrow(Z_scores.DE.sel), pch=16, cex=1.5,
           col=choose.cols(Z_scores.DE.sel[res.hc$order, 1]))
  
  #proportion of overlap
  for(i in 1:nrow(Z_scores.DE.sel)){
    if(i%%2==0){polygon(x=c(3, 3, 8, 8), y=c(i-0.4, i+0.4, i+0.4, i-0.4), border = NA, col="gray95")}
    else{polygon(x=c(3, 3, 8, 8), y=c(i-0.4, i+0.4, i+0.4, i-0.4), border = NA, col="gray98")}
  }
  abline(v=5.5, col="gray")
  points(5.5+Z_scores.DE.sel[res.hc$order, 2], 1:nrow(Z_scores.DE.sel), pch=16, cex=1.25,
         col=choose.cols(Z_scores.DE.sel[res.hc$order, 2]))
  segments(5.5+Z_scores.DE.sel[res.hc$order, 2], 1:nrow(Z_scores.DE.sel), 
           5.5, 1:nrow(Z_scores.DE.sel), pch=16, cex=1.5,
           col=choose.cols(Z_scores.DE.sel[res.hc$order, 2]))
  
  #gene ranking correlation
  for(i in 1:nrow(Z_scores.DE.sel)){
    if(i%%2==0){polygon(x=c(8.5, 8.5, 13.5, 13.5), y=c(i-0.4, i+0.4, i+0.4, i-0.4), border = NA, col="gray95")}
    else{polygon(x=c(8.5, 8.5, 13.5, 13.5), y=c(i-0.4, i+0.4, i+0.4, i-0.4), border = NA, col="gray98")}
  }
  abline(v=11, col="gray")
  points(11+Z_scores.DE.sel[res.hc$order, 3], 1:nrow(Z_scores.DE.sel), pch=16, cex=1.25,
         col=choose.cols(Z_scores.DE.sel[res.hc$order, 3]))
  segments(11+Z_scores.DE.sel[res.hc$order, 3], 1:nrow(Z_scores.DE.sel), 
           11, 1:nrow(Z_scores.DE.sel), pch=16, cex=1.5,
           col=choose.cols(Z_scores.DE.sel[res.hc$order, 3]))
  
  #LFC correlation
  for(i in 1:nrow(Z_scores.DE.sel)){
    if(i%%2==0){polygon(x=c(14, 14, 19, 19), y=c(i-0.4, i+0.4, i+0.4, i-0.4), border = NA, col="gray95")}
    else{polygon(x=c(14, 14, 19, 19), y=c(i-0.4, i+0.4, i+0.4, i-0.4), border = NA, col="gray98")}
  }
  abline(v=16.5, col="gray")
  points(16.5+Z_scores.DE.sel[res.hc$order, 4], 1:nrow(Z_scores.DE.sel), pch=16, cex=1.25,
         col=choose.cols(Z_scores.DE.sel[res.hc$order, 4]))
  segments(16.5+Z_scores.DE.sel[res.hc$order, 4], 1:nrow(Z_scores.DE.sel), 
           16.5, 1:nrow(Z_scores.DE.sel), pch=16, cex=1.5,
           col=choose.cols(Z_scores.DE.sel[res.hc$order, 4]))
  dev.off()
  
  
  
  #mRNA vs lncRNA
  SDE.prop      <- all.SDE.prop[, c("Zhang (mRNA)", "Zhang (lncRNA)", "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")]
  colnames(SDE.prop) <- paste0("SDE.prop - ", colnames(SDE.prop))
  overlap.prop  <- all.mean.overlap.prop[rownames(SDE.prop), c("Zhang (mRNA)", "Zhang (lncRNA)", "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")]
  colnames(overlap.prop) <- paste0("overlap.prop - ", colnames(overlap.prop))
  mean.rank.cor <- all.mean.rank.cor[rownames(SDE.prop), c("Zhang (mRNA)", "Zhang (lncRNA)", "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")]
  colnames(mean.rank.cor) <- paste0("mean.rank.cor - ", colnames(mean.rank.cor))
  mean.LFC.cor  <- all.mean.lfc.cor[rownames(SDE.prop), c("Zhang (mRNA)", "Zhang (lncRNA)", "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")]
  colnames(mean.LFC.cor) <- paste0("mean.LFC.cor - ", colnames(mean.LFC.cor))
  
  summary.mat <- cbind(SDE.prop, overlap.prop, mean.rank.cor, mean.LFC.cor)
  summary.mat$DE.tool <- rownames(summary.mat)
  summary.mat <- melt(summary.mat) 
  summary.mat$summary.stat <- sapply(1:nrow(summary.mat), function(i) unlist(strsplit(as.character(summary.mat$variable[i]), "[-]"))[1])
  summary.mat$data         <- sapply(1:nrow(summary.mat), function(i) unlist(strsplit(as.character(summary.mat$variable[i]), "[-]"))[2])
  summary.mat$data.name    <- sapply(1:nrow(summary.mat), function(i) unlist(strsplit(as.character(summary.mat$data[i]), "[(]"))[1])
  summary.mat$biotype      <- sapply(1:nrow(summary.mat), function(i) unlist(strsplit(as.character(summary.mat$data[i]), "[(]"))[2])
  summary.mat$biotype      <- ifelse(summary.mat$biotype=="mRNA)", "mRNA", "lncRNA")
  summary.mat              <- summary.mat[, c("data.name", "biotype", "summary.stat", "DE.tool", "value")]
  summary.mat$summary.stat <- sapply(1:nrow(summary.mat), function(i){
    x <-  summary.mat$summary.stat[i]
    if(x=="mean.LFC.cor ")  {"similarity of LFC"}
    else if(x== "mean.rank.cor ") {"gene ranking agreement"}
    else if(x== "overlap.prop ") {"proportion of overlap"}
    else if(x== "SDE.prop ") {"proportion of SDE genes"}
  })
  summary.mat$abline <- NA
  summary.mat$abline[which(summary.mat$summary.stat =="proportion of SDE genes" & 
                             summary.mat$biotype == "mRNA" & summary.mat$data.name ==" Zhang ")] <- 0.61
  summary.mat$abline[which(summary.mat$summary.stat =="proportion of SDE genes" & 
                             summary.mat$biotype == "lncRNA" & summary.mat$data.name ==" Zhang ")] <- 0.39
  summary.mat$abline[which(summary.mat$summary.stat =="proportion of SDE genes" & 
                             summary.mat$biotype == "mRNA" & summary.mat$data.name ==" NGP Nutlin ")] <- 0.63
  summary.mat$abline[which(summary.mat$summary.stat =="proportion of SDE genes" & 
                             summary.mat$biotype == "lncRNA" & summary.mat$data.name ==" NGP Nutlin ")] <- 0.37
  
  win.graph()
  ggplot(summary.mat, aes(x=DE.tool, y=value, group=interaction(biotype, data.name, summary.stat), colour=biotype))+
    geom_point(stat = "identity", position = "identity", size=3)+
    facet_grid(data.name~summary.stat, as.table=TRUE, scales = "free")+
    coord_flip()+
    scale_color_manual("", values = c("orange", "deepskyblue3")) + 
    theme(axis.title.x = element_text(size=15),
          axis.title.y = element_text(size=15),
          panel.background = element_rect(fill = "gray90", colour = "grey90"),
          strip.text = element_text(size=15),
          legend.position = "top",
          legend.title = element_blank())+
    labs(y="", x="", title="")
  #geom_hline(yintercept = summary.mat$abline)

