###############################################################################
processed_Zhang_data <- function(){
  ##### Loading annotated and processed data
  counts_Neuroblastoma <- readRDS(".../Additional File 6/Data/Zhang/raw data/counts_Neuroblastoma.RData")
  counts.source <- counts_Neuroblastoma[[1]]  #32463 genes and 172 samples
  group.source <- counts_Neuroblastoma[[2]]
  gr0 <-which(group.source == 0)
  gr1 <-which(group.source == 1)
  counts.source <- counts.source[, c(gr0, gr1)]
  group.source <- group.source[c(gr0, gr1)]
  geneBiotype.source <- counts_Neuroblastoma[[3]]
  
  #Filtering genes with at least 1 expression across samples whin each condition
  keep = which(rowSums(counts.source)>0)
  #length(keep)
  #Now we have 32471 genes
  counts.source <- counts.source[keep,]
  
  #Genes Biotype
  lncRNA <- geneBiotype.source$Gene_Name[geneBiotype.source$Gene_Biotype %in% 
                                           c("3prime_overlapping_ncrna", "ambiguous_orf", "antisense", "antisense_RNA", "lincRNA",  
                                             "ncrna_host"," processed_transcript", "sense_intronic", "sense_overlapping")]
  lncRNA <- rownames(counts.source)[rownames(counts.source) %in% lncRNA]
  mRNA <- geneBiotype.source$Gene_Name[geneBiotype.source$Gene_Biotype == "protein_coding"]
  mRNA <- rownames(counts.source)[rownames(counts.source) %in% mRNA]
  
  
  #randomly selecting 20 samples from each group
  set.seed(1246)
  grp <- as.factor(group.source)
  ind_group1 <- sort(sample(1:length(which(group.source==levels(grp)[1])), 20))
  ind_group2 <- length(which(group.source==levels(grp)[1])) + sort(sample(1:length(which(group.source==levels(grp)[2])), 20))
  
  counts <- counts.source[, c(ind_group1, ind_group2)]
  colnames(counts) <- c(paste0("condA", 1:20), paste0("condB", 1:20))
  
  group  <- as.factor(rep(c("condA", "condB"), each=20))
  counts <- counts[which(rowSums(counts[, group == levels(group)[1]]) > 0 &
                           rowSums(counts[, group == levels(group)[2]]) > 0),]
  counts.mRNA <- counts[which(rownames(counts) %in% mRNA), ]
  counts.lncRNA <- counts[which(rownames(counts) %in% lncRNA), ]
  
  dim(counts) ; dim(counts.mRNA) ; dim(counts.lncRNA)
  #29303 genes, in which 19254 mRNA genes and 10051 lncRNAs
  
  Zhang <- list(counts=counts, counts.mRNA=counts.mRNA, counts.lncRNA=counts.lncRNA, group=group,
                mRNA=mRNA, lncRNA=lncRNA)
  saveRDS(Zhang, 
          ".../Additional File 6/Data/Zhang/Zhang_Data_20and20.RData")
  rm(list = ls())
}

rm(list = ls())

###### Set working directory
setwd(".../Additional File 6/Concordance Analysis/Zhang")


######  running DE tools
source(".../Additional File 6/Concordance Analysis/All_DE_tools_for_concordance_analysis.R")

#importing data
read <- readRDS(".../Additional File 6/Data/Zhang/Zhang_Data_20and20.RData")
counts  <- read$counts
group  <- read$group
mRNA <- read$mRNA ; mRNA <- rownames(counts)[which(rownames(counts) %in% mRNA)]
lncRNA <- read$lncRNA ; lncRNA <- rownames(counts)[which(rownames(counts) %in% lncRNA)]

counts <- counts[which(rowSums(counts[, group == levels(group)[1]]) > 0 &
                         rowSums(counts[, group == levels(group)[2]]) > 0),]
counts.mRNA   <- counts[rownames(counts) %in% mRNA, ]
counts.lncRNA <- counts[rownames(counts) %in% lncRNA, ]

dim(counts) ; dim(counts.mRNA) ; dim(counts.lncRNA)
#29303 genes, in which 19252 mRNA genes and 10051 lncRNAs

############################## Exploratory Data Analysis ###############################################

#Correlation summary
cor.summary <- function(counts, group){
  group <- as.factor(group)
  counts <- counts[, c(which(group == levels(group)[1]), 
                       which(group == levels(group)[2]))]
  
  WC1 <- cor(counts[, which(group == levels(group)[1])])
  WC1 <- WC1[lower.tri(WC1, diag = FALSE)]
  WC2 <- cor(counts[, which(group == levels(group)[2])])
  WC2 <- WC2[lower.tri(WC2, diag = FALSE)]
  
  WC.summary <- quantile(c(WC1, WC2), prob=c(0, 0.25, 0.5, 0.75, 1))
  
  BC <- cor(counts)[1:length(which(group == levels(group)[1])),
                    (length(which(group == levels(group)[1]))+1):length(group)]
  BC <- BC[lower.tri(BC, diag = FALSE)]
  BC.summary <- quantile(BC, prob=c(0, 0.25, 0.5, 0.75, 1))
  
  return(list(within.cor=WC.summary, between.cor =BC.summary ))
}
cor.summary(counts.full[mRNA,], group.full)
cor.summary(counts.full[lncRNA,], group.full)

#Library sizes
summary(colSums(counts.full[mRNA,])) ; summary(colSums(counts.full[lncRNA,]))
#Exolring biological coefficient of variability (BCV) using edgeR

library(edgeR)
win.graph()
par(mfrow=c(1,2))
#mRNA
y.mRNA <- DGEList(counts=counts.full[mRNA,], group=group.full)
y.mRNA <- calcNormFactors(y.mRNA)
y.mRNA <- estimateDisp(y.mRNA, design)
plotBCV(y.mRNA, ylim=c(0, 12), main="Zhang (mRNA)", cex.lab=1.5)
text(7, 4, "Common Dispersion = 0.453 \n Common BCV = 0.673", cex=1.5, col=2)

#lncRNA
y.lncRNA <- DGEList(counts=counts.full[lncRNA,], group=group.full)
y.lncRNA <- calcNormFactors(y.lncRNA)
design <- model.matrix(~group.full)
y.lncRNA <- estimateCommonDisp(y.lncRNA, design)
y.lncRNA <- estimateGLMCommonDisp(y.lncRNA, design, verbose=TRUE)
y.lncRNA <- estimateGLMTrendedDisp(y.lncRNA, design)
y.lncRNA <- estimateGLMTagwiseDisp(y.lncRNA, design)
plotBCV(y.lncRNA, ylim=c(0, 12), main="Zhang (lncRNA)", cex.lab=1.5)
text(7, 4, "Common Dispersion = 0.541 \n Common BCV = 0.735", cex=1.5, col=2)

y <- DGEList(counts=counts.full, group=group.full)
y <- calcNormFactors(y)
design <- model.matrix(~group.full)
y <- estimateDisp(y, design)
biotype <- rep(NA, nrow(counts.full))
biotype[which(rownames(counts.full) %in% mRNA)] <- "mRNA"
biotype[which(rownames(counts.full) %in% lncRNA)] <- "lncRNA"
vioplot::vioplot(log(y$tagwise.dispersion)~biotype)


#PCA plot to setect batch effect
library("DESeq2")
dds <- DESeqDataSetFromMatrix(counts, DataFrame(group), ~ group)
dds <- estimateSizeFactors(dds)
dds <- dds[ rowSums(counts(dds, normalize=T)) > 1, ]
nrow(dds)
rld <- rlog(dds, blind = FALSE)
DESeq2::plotPCA(rld, intgroup="group", ntop = 1000)


############################## Running DGE analysis ###############################
###### Set analysis output object
results.full <- list()
# edgeR - classic
results.full["edgeR_exact"]            <- list(runedgeR_exact(count.dat=counts, conditions=group,
                                                              colors=colors,path=outputpath))
# edgeR - glm
results.full["edgeR_glm"]              <- list(runedgeR_glm(count.dat=counts, conditions=group,
                                                            colors=colors,path=outputpath))
# edgeR - robust with prior degree of freedom 10
results.full["edgeR_rob_pDF10"]        <- list(runedgeR_rob_pDF10(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))
# edgeR - robust with prior degree of freedom 5
results.full["edgeR_rob_pDF05"]        <- list(runedgeR_rob_pDF05(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))
# edgeR - robust with prior degree of freedom 15
results.full["edgeR_rob_pDF20"]        <- list(runedgeR_rob_pDF20(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))
# edgeR - robust with prior degree of freedom 15
results.full["edgeR_rob_auto.pDF"]        <- list(runedgeR_rob_auto.pDF(count.dat=counts, conditions=group,
                                                                        colors=colors,path=outputpath))

# edgeR - quasi-likelihood 
results.full["edgeR_ql"]               <- list(runedgeR_ql(count.dat=counts, conditions=group,
                                                           colors=colors,path=outputpath))

# DESeq
results.full["DESeq"]                  <- list(runDESeq(count.dat=counts, conditions=group,
                                                        colors=colors,path=outputpath))

# DESeq2 -- independent.filtering=FALSE, Cook's cut= TRUE
results.full["DESeq2_indFilterDeactive"] <- list(runDESeq2_indFilterDeactive(count.dat=counts, conditions=group,
                                                                             colors=colors,path=outputpath))
# DESeq2 -- independent.filtering=FALSE, Cook's cut= FALSE
results.full["DESeq2_indFilterDeactiveCooksOff"] <- list(runDESeq2_indFilterDeactiveCooksOff(count.dat=counts, conditions=group,
                                                                                             colors=colors,path=outputpath))
# DESeq2 --Default-- independent.filtering=TRUE, Cook's cut= TRUE
results.full["DESeq2_indFilterActive"] <- list(runDESeq2_indFilterActive(count.dat=counts, conditions=group,
                                                                         colors=colors,path=outputpath))


# Limma + quantile normalization
results.full["LimmaQN"]               <- list(runLimmaQN(count.dat=counts, conditions=group,
                                                         colors=colors,path=outputpath))
# LimmaVoom with LSE estimation
results.full["LimmaVoom"]             <- list(runLimmaVoom(count.dat=counts, conditions=group,
                                                           colors=colors,path=outputpath))
# LimmaVoom with robust estimation
results.full["LimmaVoom_Robust"]      <- list(runLimmaVoom_Robust(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))

# LimmaTrended with LSE estimation
results.full["LimmaTrended"]          <- list(runLimmaTrended(count.dat=counts, conditions=group,
                                                              colors=colors,path=outputpath))
# LimmaTrended with robust estimation
results.full["LimmaTrended_Robust"]   <- list(runLimmaTrended_Robust(count.dat=counts, conditions=group,
                                                                     colors=colors,path=outputpath))

# LimmaVoom (with quality weights)
results.full["LimmaVoom_QW"]          <- list(runLimmaVoom_QW(count.dat=counts, conditions=group,
                                                              colors=colors,path=outputpath))
# LimmaVst 
results.full["LimmaVst"]              <- list(runLimmaVst(count.dat=counts, conditions=group,
                                                          colors=colors,path=outputpath))


# BaySeq
results.full["BaySeq"]               <- list(runBaySeq(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))


# PoissonSeq -> Note: pass adapted cut-off to method if required
results.full["PoissonSeq"]            <- list(runPoissonSeq(count.dat=counts, conditions=group,
                                                            colors=colors,path=outputpath))

# SAMSeq
results.full["SAMSeq"]               <- list(runSAMSeq(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))


# QuasiSeq: QL
results.full["QuasiSeq_QL"]          <- list(runQuasiSeq_QL(count.dat=counts, conditions=group,
                                                            colors=colors,path=outputpath))
# QuasiSeq: QLShrink
results.full["QuasiSeq_QLShrink"]    <- list(runQuasiSeq_QLShrink(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))
# QuasiSeq: QLSpline
results.full["QuasiSeq_QLSpline"]    <- list(runQuasiSeq_QLSpline(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))

#NOISeq
results.full["NOISeq"]               <- list(runNOISeq(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))


#Saving result
saveRDS(results.full, file="result_full_Zhang.RData")



############################## Concordance Analysis between DE tools ########################
#Loading saved result of CRC AZA analysis
results.full <- readRDS("result_full_Zhang.RData")
methods <- names(results.full)

## organaizing results
library(DESeq)
cds <- DESeq::newCountDataSet(counts, group)
cds <- DESeq::estimateSizeFactors(cds)
norm.counts <- counts(cds, normalized=TRUE)

classical.LFC.estimates <- data.frame(classical.LFC = apply(norm.counts, 1, function(x) {
  mu.g1 <- mean(x[group==levels(group)[1]])
  mu.g2 <- mean(x[group==levels(group)[2]])
  if(mu.g1 != 0 & mu.g2 != 0) {lfc <- log2(mu.g2/mu.g1)}
  else if(mu.g1 != 0 & mu.g2 == 0) {lfc <- -log2(mu.g1)}
  else if(mu.g1 == 0 & mu.g2 != 0) {lfc <- log2(mu.g2)}
  return(lfc) }))
classical.LFC.estimates$ID <- rownames(classical.LFC.estimates)

Merge.DE.results <- function(results.full, na.treat ="keep"){
  #A function that returns the rank of genes for all methods 
  methods <-  names(results.full)
  
  df1 <- results.full[1][[paste(methods[1])]]$summary
  df1 <- merge(df1, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
  df1$pval[is.na(df1$pval)] <- 1
  df1$signed.pval <- sign(df1$classical.LFC)*(df1$pval+1e-5)  #A constant +1e-5 is added to each pvalues to avoid 0 signed p-value when p-value is 0
  df1$pi.score <- abs(df1$classical.LFC)*(-log10(df1$pval+1e-5))
  
  df2 <- results.full[2][[paste(methods[2])]]$summary
  df2 <- merge(df2, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
  df2$pval[is.na(df2$pval)] <- 1
  df2$signed.pval <- sign(df2$classical.LFC)*(df2$pval+1e-5)
  df2$pi.score <- abs(df2$classical.LFC)*(-log10(df2$pval+1e-5))
  
  
  summary.all <- merge(df1, df2, by ="ID", all.x=T, all.y=T)
  colnames(summary.all) <- c("ID", paste(methods[1],".", c(colnames(df1)), sep="")[-1], 
                             paste(methods[2],".", c(colnames(df2)), sep="")[-1])
  
  for(i in 3:length(methods)){
    df.i <- results.full[i][[paste(methods[i])]]$summary
    df.i <- merge(df.i, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df.i$pval[is.na(df.i$pval)] <- 1
    
    if(methods[i] !="SAMSeq"){
      df.i$signed.pval <- sign(df.i$classical.LFC)*(df.i$pval+1e-5)
      df.i$pi.score    <- abs(df.i$classical.LFC)*(-log10(df.i$pval+1e-5))
    } 
    else if(methods[i] == "SAMSeq"){
      df.i$stat[is.na(df.i$stat)] <- 0
      df.i$signed.pval <- sign(df.i$classical.LFC)*(1/abs(df.i$stat+1e-5))
      df.i$pi.score    <- abs(df.i$classical.LFC)*(-log10(1/abs(df.i$stat+1e-5)))
    }
    colnames(df.i) <- c("ID", paste(methods[i], ".", colnames(df.i), sep="")[-1])
    
    summary.all <- merge(summary.all, df.i, by ="ID", all.x=T, all.y=T)
    #colnames(summary.all) <- c("ID", methods[1:i])
  }
  
  rownames(summary.all) <- summary.all$ID
  summary.all <- summary.all[,-1]
  
  return(summary.all)
}


#Merging summary results of all the methods
summary.all <- Merge.DE.results(results.full)
dim(summary.all)

methods.name <- c("edgeR exact", "edgeR GLM", "edgeR robust (pDF=10)", "edgeR robust (pDF=5)", 
                  "edgeR robust (pDF=20)", "edgeR robust (pDF=auto)", "edgeR QL",  "DESeq", 
                  "DESeq2 (indFilt=OFF)", "DESeq2 (indFilt=OFF, CooksCut=OFF)", "DESeq2 (indFilt=ON)",
                  "limmaQN", "limmaVoom", "limmaVoom (robust)", 
                  "limmaTrended", "limmaTrended (robust)", "limmaVoom + QW", "limmaVst", 
                  "baySeq", "PoissonSeq", "SAMSeq", 
                  "QuasiSeq (QL)", "QuasiSeq (QLShrink)", "QuasiSeq (QLSpline)",
                  "NOISeq")



#------------------------------------------------------------------------#
#GENE RANK ANALYSIS 
#Spearman's Rank Correlation Matrix
#columns <- paste(methods,".", "signed.pval", sep="")
columns <- paste(methods,".", "pi.score", sep="")
score.matrix <- summary.all[,c(columns)]
colnames(score.matrix) <- methods.name

#classical LFC estimates
columns <- paste(methods,".", "classical.LFC", sep="")
LFC.matrix <- summary.all[,c(columns)]
colnames(LFC.matrix) <- methods.name
LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
rownames(LFC.matrix) <- rownames(summary.all)


#subsetting the top commonly identifed SDE genes across methods
columns <- paste(methods,".", "padj", sep="")
padj.matrix <- summary.all[,c(columns)]
padj.matrix[is.na(padj.matrix)] = 1   #replacing NA values by 1
colnames(padj.matrix) <- methods.name

common.SDE.genes <- names(which(apply(padj.matrix, 1, function(x) {
  if(max(x) < 1) {return(1)}
  else {return(0)}}) == 1))
length(common.SDE.genes)

common.SDE.genes.mRNA   <- common.SDE.genes[which(common.SDE.genes %in% mRNA)]
common.SDE.genes.lncRNA <- common.SDE.genes[which(common.SDE.genes %in% lncRNA)]
length(common.SDE.genes.mRNA) ; length(common.SDE.genes.lncRNA)

#Rank correlation, ranks scores and if there are ties, it uses auxillary information to break ties
rank.cov <- function(y, x=NULL, na.last=TRUE, ties.method="average"){
  r <- y
  if(is.null(x)) {r <- rank(y, na.last=na.last, ties.method=ties.method)}
  else if(!is.null(x)){
    r.temp <- rank(y, na.last=na.last, ties.method="min")
    t.r <- table(r.temp)
    ties <- as.numeric(names(which(t.r>1)))
    if(length(ties)>=1) {
      for(i in 1:length(ties)){
        r.cov <- rank(x[r.temp==ties[i]])-1
        r.temp[r.temp==ties[i]] <- r.temp[r.temp==ties[i]] + r.cov
      }
    }
    else{
      r.temp <- rank(y, na.last=na.last, ties.method=ties.method)
    }
    r <- r.temp 
  }
  return(r)
}

#mRNA
rank.matrix.mRNA <- apply(score.matrix[which(rownames(score.matrix) %in% common.SDE.genes.mRNA), ], 2, function(v){
  rank.cov(v, x=LFC.matrix[which(rownames(LFC.matrix) %in% common.SDE.genes.mRNA), 1])
})
#rank.matrix.mRNA <- rank.matrix.mRNA[common.SDE.genes.mRNA, ]

#lncRNA
rank.matrix.lncRNA <- apply(score.matrix[which(rownames(score.matrix) %in% common.SDE.genes.lncRNA), ], 2, function(v){
  rank.cov(v, x=LFC.matrix[which(rownames(LFC.matrix) %in% common.SDE.genes.lncRNA), 1])
})

#mRNA
cor.rank.mRNA <- round(cor(rank.matrix.mRNA, use = "pairwise.complete.obs", method ="spearman"), 3)
cor.rank.mRNA.2 <- cor.rank.mRNA
diag(cor.rank.mRNA.2) <- NA
mean.cor.mRNA <- apply(cor.rank.mRNA.2, 1, function(x) mean(x, na.rm=T))
saveRDS(mean.cor.mRNA, "mean.rank.cor.mRNA.RData")

cor.rank.mRNA[lower.tri(cor.rank.mRNA, diag = T)] <- NA
cor.rank.mRNA


#lncRNA
cor.rank.lncRNA <- round(cor(rank.matrix.lncRNA, use = "pairwise.complete.obs", method ="spearman"), 3)
cor.rank.lncRNA.2 <- cor.rank.lncRNA
diag(cor.rank.lncRNA.2) <- NA
mean.cor.lncRNA <- apply(cor.rank.lncRNA.2, 1, function(x) mean(x, na.rm=T))
saveRDS(mean.cor.lncRNA, "mean.rank.cor.lncRNA.RData")

cor.rank.lncRNA[lower.tri(cor.rank.lncRNA, diag = T)] <- NA
cor.rank.lncRNA



library(corrplot)
library(RColorBrewer)

win.graph()
par(mfrow=c(1,1))
#par(mar=c(4,4, 4,4)+0.35)
cor.rank.full.mRNA <- round(cor(rank.matrix.mRNA, use = "pairwise.complete.obs", method ="spearman"), 3)
corrplot(cor.rank.full.mRNA, type = "lower", order = "hclust", tl.srt = 20, cl.lim = c(0.65, 1),
         is.corr = FALSE, col =  brewer.pal(n = 8, name = "Spectral"), diag = FALSE,
         title ="pairwise Spearman's rank correlation coefficients \n mRNA", cex.lab=1.25, mar=c(0,0, 0,0))

win.graph()
par(mfrow=c(1,1))
cor.rank.full.lncRNA <- round(cor(rank.matrix.lncRNA, use = "pairwise.complete.obs", method ="spearman"), 3)
corrplot(cor.rank.full.lncRNA, type = "lower", order = "hclust", tl.srt = 20, cl.lim = c(0.65, 1),
         is.corr = FALSE, col =  brewer.pal(n = 8, name = "Spectral"), diag = FALSE,
         title ="pairwise Spearman's rank correlation coefficients \n lncRNA", cex.lab=1.25, mar=c(0,0,0,0))


win.graph()
par(mfrow=c(1,1))
par(mar=c(4,18, 4, 4)+0.05)
plot(sort(mean.cor.mRNA, decreasing = TRUE), 1:25, pch=20, cex=2, col="blue", cex.lab=1.25,
     las=1, xlim = c(0.8, 1), axes=FALSE, ylab="", xlab="mean correlation",
     main="mean Spearman's rank \n correlation coefficient")
points(sort(mean.cor.lncRNA, decreasing = TRUE), 1:25, pch=20, cex=2, col="orange")
axis(1, seq(0.8, 1, 0.1), col="gray", lwd=2)
axis(2, at=1:25, names(sort(mean.cor.mRNA, decreasing = TRUE)), col="gray", lwd=2, las=1)
segments(rep(0, 24), 1:25, sort(mean.cor.mRNA, decreasing = TRUE), 1:25, col="gray")
legend("bottomleft", c("mRNA", "lncRNA"), pch=20, col=c("blue", "orange"), pt.cex = 2)
par(mar=c(4,4, 4, 4)+0.1)

#------------------------------------------------------------------------#
#ANALYSIS OF NUMBER OF DE GENES and CLLASSIFICATION OVERLAPPING
columns <- paste(methods,".", "padj", sep="")
padj.matrix <- summary.all[,c(columns)]
colnames(padj.matrix) <- methods

DE.indicator <- padj.matrix
for(i in 1:nrow(padj.matrix)){
  for(j in 1:ncol(padj.matrix)){
    if(padj.matrix[i,j] < 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 1
    else if(padj.matrix[i,j] >= 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 0
  }
}


biotype <- ifelse(rownames(DE.indicator) %in% mRNA, "mRNA", "lncRNA")
library(reshape2)
DE.indicator2 <- melt(DE.indicator)
DE.indicator2 <- data.frame(DE.indicator2, biotype =rep(biotype, times=length(methods)))
colnames(DE.indicator2) <- c("Methods", "DE", "biotype")

agr <- aggregate(DE~Methods+biotype, data=DE.indicator2, FUN=sum)
agr.all <- aggregate(DE~Methods, data=DE.indicator2, FUN=sum)
agr.all$Methods <- agr$Methods <- methods.name
saveRDS(list(agr.all=agr.all, agr=agr), "SDE.summary.RData")

library(ggplot2)
library(gridExtra)

win.graph()
pl1 <- ggplot(agr, aes(x=reorder(Methods, DE), y=DE, fill=biotype)) + 
  geom_bar(stat="identity", position = "stack")+ 
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
        legend.position=c(0.2, 0.9)) + 
  scale_x_discrete(breaks=methods.name, labels=methods.name)+
  labs(title="A", x="DE tools", y="mumber of SDE genes (at 5% FDR)",
       fill="genes biotypes")

pl2 <- ggplot(agr,  aes(x=Methods, y=DE, fill=biotype)) + 
  geom_bar(stat="identity", position = "fill")+
  theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position='none') + 
  scale_x_discrete(breaks=methods.name, labels=methods.name)+
  labs(title="B", x="DE tools", y="proportion")
grid.arrange(pl1, pl2, ncol=2)


#Overlapping of DE classification
#mRNA
DE.indicator.mRNA <- DE.indicator[which(rownames(DE.indicator) %in% mRNA), ]
overlap.mRNA <- matrix(NA, ncol=length(methods), nrow=length(methods))
for(i in 1:nrow(overlap.mRNA)){
  for(j in 1:ncol(overlap.mRNA)){
    overlap.mRNA[i,j] <- length(which(DE.indicator.mRNA[,i]==1 & DE.indicator.mRNA[,j]==1))
  }
}
colnames(overlap.mRNA) <- methods.name
rownames(overlap.mRNA) <- methods.name

non.overlap.mRNA.A <- matrix(NA, ncol=length(methods), nrow=length(methods))
for(i in 1:nrow(non.overlap.mRNA.A)){
  for(j in 1:ncol(non.overlap.mRNA.A)){
    non.overlap.mRNA.A[i,j] <- length(which(DE.indicator.mRNA[,i]==1 & DE.indicator.mRNA[,j]==0))
  }
}
colnames(non.overlap.mRNA.A) <- methods.name
rownames(non.overlap.mRNA.A) <- methods.name

non.overlap.mRNA.B <- t(non.overlap.mRNA.A)

overlap.mRNA.prop <-overlap.mRNA/(non.overlap.mRNA.A+overlap.mRNA+non.overlap.mRNA.B)
rownames(overlap.mRNA.prop) <- methods.name
colnames(overlap.mRNA.prop) <- methods.name

# number_of.SDE.mRNA <- diag(overlap.mRNA)
# base.mRNA <- overlap.mRNA
# for(i in 1:nrow(base.mRNA)){
#   for(j in 1:ncol(base.mRNA)){
#     base.mRNA[i,j] <- min(number_of.SDE.mRNA[i], number_of.SDE.mRNA[j])
#   }
# }
# overlap.prop.mRNA <- overlap.mRNA/base.mRNA
# rownames(overlap.prop.mRNA) <- methods.name
# colnames(overlap.prop.mRNA) <- methods.name

overlap.prop.mRNA.2 <- overlap.mRNA.prop
diag(overlap.prop.mRNA.2) <- NA
mean.overlap.mRNA <- apply( overlap.prop.mRNA.2, 1, function(x) mean(x, na.rm=T))
saveRDS(mean.overlap.mRNA, "mean.overlap.prop.mRNA.RData")


#lncRNA
DE.indicator.lncRNA <- DE.indicator[which(rownames(DE.indicator) %in% lncRNA), ]
overlap.lncRNA <- matrix(NA, ncol=length(methods), nrow=length(methods))
for(i in 1:nrow(overlap.lncRNA)){
  for(j in 1:ncol(overlap.lncRNA)){
    overlap.lncRNA[i,j] <- length(which(DE.indicator.lncRNA[,i]==1 & DE.indicator.lncRNA[,j]==1))
  }
}
colnames(overlap.lncRNA) <- methods.name
rownames(overlap.lncRNA) <- methods.name

non.overlap.lncRNA.A <- matrix(NA, ncol=length(methods), nrow=length(methods))
for(i in 1:nrow(non.overlap.lncRNA.A)){
  for(j in 1:ncol(non.overlap.lncRNA.A)){
    non.overlap.lncRNA.A[i,j] <- length(which(DE.indicator.lncRNA[,i]==1 & DE.indicator.lncRNA[,j]==0))
  }
}
colnames(non.overlap.lncRNA.A) <- methods.name
rownames(non.overlap.lncRNA.A) <- methods.name

non.overlap.lncRNA.B <- t(non.overlap.lncRNA.A)

overlap.lncRNA.prop <-overlap.lncRNA/(non.overlap.lncRNA.A+overlap.lncRNA+non.overlap.lncRNA.B)
rownames(overlap.lncRNA.prop) <- methods.name
colnames(overlap.lncRNA.prop) <- methods.name

# number_of.SDE.lncRNA <- diag(overlap.lncRNA)
# base.lncRNA <- overlap.lncRNA
# for(i in 1:nrow(base.lncRNA)){
#   for(j in 1:ncol(base.lncRNA)){
#     base.lncRNA[i,j] <- min(number_of.SDE.lncRNA[i], number_of.SDE.lncRNA[j])
#   }
# }
# overlap.prop.lncRNA <- overlap.lncRNA/base.lncRNA
# rownames(overlap.prop.lncRNA) <- methods.name
# colnames(overlap.prop.lncRNA) <- methods.name

overlap.prop.lncRNA.2 <- overlap.lncRNA.prop
diag(overlap.prop.lncRNA.2) <- NA
mean.overlap.lncRNA <- apply( overlap.prop.lncRNA.2, 1, function(x) mean(x, na.rm=T))
saveRDS(mean.overlap.lncRNA, "mean.overlap.prop.lncRNA.RData")




library(corrplot)
library(RColorBrewer)

win.graph()
par(mfrow=c(1,1))
#par(mar=c(4,4, 4,4)+0.35)
overlap.mRNA.prop <-overlap.mRNA/(non.overlap.mRNA.A+overlap.mRNA+non.overlap.mRNA.B)
rownames(overlap.mRNA.prop) <- methods.name
colnames(overlap.mRNA.prop) <- methods.name
corrplot(overlap.mRNA.prop, type = "lower", order = "hclust", tl.srt = 20, cl.lim = c(0, 1),
         is.corr = FALSE, col =  brewer.pal(n = 6, name = "Spectral"), diag = FALSE,
         title ="pairwise proportion of overlap\n mRNA", cex.lab=1.25, mar=c(0,0, 0,0))

win.graph()
par(mfrow=c(1,1))
overlap.lncRNA.prop <-overlap.lncRNA/(non.overlap.lncRNA.A+overlap.lncRNA+non.overlap.lncRNA.B)
rownames(overlap.lncRNA.prop) <- methods.name
colnames(overlap.lncRNA.prop) <- methods.name
corrplot(overlap.lncRNA.prop, type = "lower", order = "hclust", tl.srt = 20, cl.lim = c(0, 1),
         is.corr = FALSE, col =  brewer.pal(n = 6, name = "Spectral"), diag = FALSE,
         title ="pairwise proportion of overlap\n lncRNA", cex.lab=1.25, mar=c(0,0, 0,0))

win.graph()
par(mfrow=c(1,1))
par(mar=c(4,18, 4, 4)+0.05)
plot(sort(mean.overlap.mRNA, decreasing = TRUE), 1:25, pch=20, cex=2, col="blue", cex.lab=1.25,
     las=1, xlim = c(0.0, 1), axes=FALSE, ylab="", xlab="mean proportion",
     main="mean overlap proportion")
points(sort(mean.overlap.lncRNA, decreasing = TRUE), 1:25, pch=20, cex=2, col="orange")
axis(1, seq(0.0, 1, 0.2), col="gray", lwd=2)
axis(2, at=1:25, names(sort(mean.overlap.mRNA, decreasing = TRUE)), col="gray", lwd=2, las=1)
segments(rep(0, 24), 1:25, sort(mean.overlap.mRNA, decreasing = TRUE), 1:25, col="gray")
legend("bottomleft", c("mRNA", "lncRNA"), pch=20, col=c("blue", "orange"), pt.cex = 2)
par(mar=c(4,4, 4, 4)+0.1)

#------------------------------------------------------------------------#
#ANALYSIS OF LFC
columns <- paste(methods,".", "logFC", sep="")
LFC.matrix <- summary.all[,c(columns)]
colnames(LFC.matrix) <- methods.name
LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
rownames(LFC.matrix) <- rownames(summary.all)

#Correlation b/n LFC estimates from each method
## mRNA
cor.lfc.mRNA <- cor(LFC.matrix[which(rownames(LFC.matrix) %in% mRNA),-21], 
                    method ="pearson", use="pairwise.complete.obs")
rownames(cor.lfc.mRNA) <- colnames(cor.lfc.mRNA) <- methods.name[-21]
cor.lfc.mRNA.2 <- cor.lfc.mRNA
diag(cor.lfc.mRNA.2) <- NA
mean.cor.lfc.mRNA <- apply(cor.lfc.mRNA.2, 1, function(x) mean(x, na.rm=T))
names(mean.cor.lfc.mRNA) <- methods.name[-21]
saveRDS(mean.cor.lfc.mRNA, "mean.lfc.cor.mRNA.RData")

## lncRNA
cor.lfc.lncRNA <- cor(LFC.matrix[which(rownames(LFC.matrix) %in% lncRNA),-21], 
                      method ="pearson", use="pairwise.complete.obs")
rownames(cor.lfc.lncRNA) <- colnames(cor.lfc.lncRNA) <- methods.name[-21]
cor.lfc.lncRNA.2 <- cor.lfc.lncRNA
diag(cor.lfc.lncRNA.2) <- NA
mean.cor.lfc.lncRNA <- apply(cor.lfc.lncRNA.2, 1, function(x) mean(x, na.rm=T))
names(mean.cor.lfc.lncRNA) <- methods.name[-21]
saveRDS(mean.cor.lfc.lncRNA, "mean.lfc.cor.lncRNA.RData")


library(corrplot)
library(RColorBrewer)

win.graph()
par(mfrow=c(1,1))
#par(mar=c(4,4, 4,4)+0.35)
cor.lfc.mRNA.full <- cor(LFC.matrix[which(rownames(LFC.matrix) %in% mRNA),-21], 
                         method ="pearson", use="pairwise.complete.obs")
rownames(cor.lfc.mRNA.full) <- methods.name[-21]
colnames(cor.lfc.mRNA.full) <- methods.name[-21]
corrplot(cor.lfc.mRNA.full, type = "lower", order = "hclust", tl.srt = 20, cl.lim = c(0.65, 1),
         is.corr = FALSE, col =  brewer.pal(n = 6, name = "Spectral"), diag = FALSE,
         title ="pairwise correlation of LFC \n mRNA", cex.lab=1.25, mar=c(0,0, 0,0))

win.graph()
par(mfrow=c(1,1))
cor.lfc.lncRNA.full <- cor(LFC.matrix[which(rownames(LFC.matrix) %in% lncRNA),-21], 
                           method ="pearson", use="pairwise.complete.obs")
rownames(cor.lfc.lncRNA.full) <- methods.name[-21]
colnames(cor.lfc.lncRNA.full) <- methods.name[-21]
corrplot(cor.lfc.lncRNA.full, type = "lower", order = "hclust", tl.srt = 20, cl.lim = c(0.65, 1),
         is.corr = FALSE, col =  brewer.pal(n = 6, name = "Spectral"), diag = FALSE,
         title ="pairwise correlation of LFC \n lncRNA", cex.lab=1.25, mar=c(0,0, 0,0))

win.graph()
par(mfrow=c(1,1))
par(mar=c(4,18, 4, 4)+0.05)
plot(sort(mean.cor.lfc.mRNA, decreasing = TRUE), 1:24, pch=20, cex=2, col="blue", cex.lab=1.25,
     las=1, xlim = c(0.75, 1), axes=FALSE, ylab="", xlab="mean correlation",
     main="mean correlation \n between pairs of LFC")
points(sort(mean.cor.lfc.lncRNA, decreasing = TRUE), 1:24, pch=20, cex=2, col="orange")
axis(1, seq(0.75, 1, 0.1), col="gray", lwd=2)
axis(2, at=1:24, names(sort(mean.cor.lfc.mRNA, decreasing = TRUE)), col="gray", lwd=2, las=1)
segments(rep(0, 23), 1:24, sort(mean.cor.lfc.mRNA, decreasing = TRUE), 1:24, col="gray")
legend("topright", c("mRNA", "lncRNA"), pch=20, col=c("blue", "orange"), pt.cex = 2)
par(mar=c(4,4, 4, 4)+0.1)


#-------------------------------------------------------------------------
#Distribution of raw p-values
columns <- paste(methods,".", "pval", sep="")
pval.matrix <- summary.all[,c(columns)]
colnames(pval.matrix) <- methods.name
pval.matrix <- as.data.frame(lapply(pval.matrix, function(x) replace(x, is.infinite(x),NA)))
rownames(pval.matrix) <- rownames(summary.all)

win.graph()
par(mfrow=c(3, 4)) 
sel.tools <- c(1, 3, 6, 7, 9, 10, 11, 12, 14, 17, 19, 21)
for(i in sel.tools){
  hist(pval.matrix[rownames(pval.matrix) %in% mRNA, i], xlim = c(0, 1), xlab="raw p-values", main = methods.name[i],
       col=rgb(0.53,0.81,0.98, 0.75), cex.lab=1.5, las=1, nclass = 30, probability = TRUE)
  hist(pval.matrix[rownames(pval.matrix) %in% lncRNA, i], nclass = 30, probability = TRUE,
       col=rgb(1,1, 0,0.25), add=T)
  if(i==1){legend(0.4, 6, c("mRNA", "lncRNA"), col=c("#87cefa", "gold"), pch=15, pt.cex = 2,
                  bty="n", ncol = 1, cex=1.25)}
}

#-------------------------------------------------------------------------
#Computational time
comput.time <- sapply(results.full, function(x) x$time)[3, ]
names(comput.time) <- methods.name
saveRDS(comput.time, "comput.time.RData")


#-------------------------------------------------------------------------
#Number of genes filtered by DESeq2 when independent filtering is on
DESEqq2_indFilter_results <- runDESeq2_indFilterActive_2(count.dat=counts, 
                                                         conditions=group)
res         <- DESEqq2_indFilter_results$summary
res$biotype <- ifelse(res$ID %in% mRNA, "mRNA", 
                      ifelse(res$ID %in% lncRNA, "lncRNA", "NA"))
head(res)
tab1 <- prop.table(table(is.na(res$padj), res$biotype), 2)
tab2 <- table(is.na(res$padj), res$biotype)
barplot(tab1[2,], main="proportion of mRNAs and lncRNAs \n  removed by DESeq2 'independent filtering' feature",
        ylim=c(0, 0.35), las=1, ylab="proportion") 
text(1, 0.301, tab2[2,1], cex=1.25, col="blue", offset=0, pos=2)
text(2, 0.061, tab2[2,2], cex=1.25, col="blue", offset=0, pos=2)