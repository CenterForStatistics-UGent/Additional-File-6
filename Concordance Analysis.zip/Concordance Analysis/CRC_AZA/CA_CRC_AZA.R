###############################################################################

#processing Hammer Data
processing_CRC_AZA_data <- function(){
  ###### Read in count data
  
  # Load count dataframe
  counts_temp <-  read.table(".../Additional File 6/Data/CRC AZA/raw data/01-Count and annotation/RNAseq_AZA.Count.txt",
                             header=TRUE, stringsAsFactors=FALSE, sep="\t", nrows=-1)
  # Create count matrix with IDs as rownames and re-ordered columns
  counts_full <- counts_temp[,c(4,7,3,5,2,6)]
  rownames(counts_full) <- counts_temp$GeneID
  # Shorten sample names in count matrix and align with names in samples dataframe
  colnames(counts_full) <- as.numeric(gsub("X","",gsub("_.*","",colnames(counts_full))))
  # Make counts integer
  counts_full <- floor(counts_full)
  
  # Test whether gene IDs are unique
  length(rownames(counts_full)) == length(unique(rownames(counts_full)))
  # -> TRUE, gene IDs are unique
  
  # Save gene names in a separate vector as well
  genedata_full <- rownames(counts_full)          
  
  ###### Read in gene annotation data (not all genes are included, version that 
  #                  includes all genes does not have indication of protein coding or not)
  #Protien codding and lncRNA are included 
  temp_genes <- read.table('.../Additional File 6/Data/CRC AZA/raw data/01-Count and annotation/gene_annotation.txt',
                           header=FALSE, stringsAsFactors=FALSE, sep="\t", nrows=-1)
  
  temp_genes2=temp_genes
  colnames(temp_genes2)=c("Gene_ID", "Gene_Type", "Gene_Name")
  ###### Read in sample annotation data
  
  temp_samples <- read.table('.../Additional File 6/Data/CRC AZA/raw data/01-Count and annotation/sample_annotation.txt',
                             header=TRUE, stringsAsFactors=FALSE, sep="\t", nrows=-1)
  temp_samples$group <- as.factor(ifelse(temp_samples$condition=='DMSO_1uM','condA','condB'))
  
  ###### Gene selection: included in annotation file, protein coding and total count >=1
  
  # Check how many genes are in the annotation file
  ingenes <- rownames(counts_full) %in% temp_genes$V3 #V3 is a column in temp_genes that stores the gene names
  table(ingenes) #-> 19715 are included in annotation file, 10658 are not
  
  # Check how many genes are in the annotation file and protein coding
  pcdata <- rownames(counts_full) %in% temp_genes$V3[temp_genes$V2=='protein_coding']
  table(pcdata) #-> 18251 genes are included in the annotation file and protein coding
  table(temp_genes$V2) 
  
  
  # Check how many of these protein coding genes have total gene count > 0
  
  genedata <- rownames(counts_full[pcdata,])[rowSums(counts_full[pcdata,])>=1]
  length(genedata)
  # -> 16499 genes are included as protein coding genes in the annotation file,
  #          and have total  count larger than 0
  genedata_unfiltered <- rownames(counts_full[pcdata,])[rowMeans(counts_full[pcdata,])>=0]
  
  
  # Create count matrix for selected genes
  counts <- counts_full[genedata,]
  
  ###### Transform count dataframes to count matrices
  counts_full <- as.matrix(counts_full) #This matrix containds all genes with any value of the total gene count
  counts <- as.matrix(counts) #This matrix containds all genes with the total gene count >=1 and with annotation file
  
  
  
  ###### Create some new variables
  nSamp <- ncol(counts)
  group <- temp_samples$group[match(as.numeric(colnames(counts)),temp_samples$sample)]
  
  ###### Rename samples
  
  colnames(counts_full) <- paste(gsub('cond','', group),rep(1:3,2),sep='')
  colnames(counts) <- paste(gsub('cond','', group),rep(1:3,2),sep='')
  
  #colnames(counts2) <- c("Gene_Name", paste(gsub('cond','', group),rep(1:3,2),sep=''), "Gene_Type")
  
  rm(counts_temp,temp_genes,temp_samples,ingenes, pcdata)
  
  saveRDS(list(counts=counts, group=group, counts_full=counts_full), 
          ".../Additional File 6/Data/CRC AZA/CRC_AZA_Data.RData")
  
  rm(list=ls())
  
}

rm(list = ls())
###### Set working directory
setwd(".../Additional File 6/Concordance Analysis/CRC_AZA/")

###### Set output folder
outputpath <- '.../Additional File 6/Concordance Analysis/CRC_AZA/' 


######  running DE tools
source(".../Additional File 6/Concordance Analysis/All_DE_tools_for_concordance_analysis.R")

##### Loading annotated and processed data
read <- readRDS(".../Additional File 6/Data/CRC AZA/CRC_AZA_Data.RData")
counts <-read$counts
group <- read$group
counts <- counts[which(rowSums(counts[, group == levels(group)[1]]) > 0 &
                         rowSums(counts[, group == levels(group)[2]]) > 0),]
dim(counts)
#14658 mRNA genes
############################## Exploratory Data Analysis ###############################################

#Correlation summary
cor.summary <- function(counts, group){
  group <- as.factor(group)
  counts <- counts[, c(which(group == levels(group)[1]), 
                       which(group == levels(group)[2]))]
  
  WC1 <- cor(counts[, which(group == levels(group)[1])])
  WC1 <- WC1[lower.tri(WC1, diag = FALSE)]
  WC2 <- cor(counts[, which(group == levels(group)[2])])
  WC2 <- WC2[lower.tri(WC2, diag = FALSE)]
  
  WC.summary <- quantile(c(WC1, WC2), prob=c(0,0.25, 0.5, 0.75, 1))
  
  BC <- cor(counts)[1:length(which(group == levels(group)[1])),
                    (length(which(group == levels(group)[1]))+1):length(group)]
  BC <- BC[lower.tri(BC, diag = FALSE)]
  BC.summary <- quantile(BC, prob=c(0, 0.25, 0.5, 0.75, 1))
  
  return(list(within.cor=WC.summary, between.cor =BC.summary ))
}
cor.summary(counts, group)

#Library size
colSums(counts)

#Exolring biological coefficient of variability (BCV) using edgeR
library(edgeR)
win.graph()
y <- DGEList(counts=counts, group=group)
y <- calcNormFactors(y)
design <- model.matrix(~group)
y <- estimateCommonDisp(y, design)
y <- estimateGLMCommonDisp(y, design, verbose=TRUE)
y <- estimateGLMTrendedDisp(y, design)
y <- estimateGLMTagwiseDisp(y, design)
plotBCV(y, ylim=c(0, 6), main="CRC AZA (mRNA)", cex.lab=1.5)
text(7, 4, "Common Dispersion = 0.010 \n Common BCV = 0.098", cex=1.5, col=2)


#PCA plot to setect batch effect
library("DESeq2")
dds <- DESeqDataSetFromMatrix(counts, DataFrame(group), ~ group)
dds <- estimateSizeFactors(dds)
dds <- dds[ rowSums(counts(dds, normalize=T)) > 1, ]
nrow(dds)
rld <- rlog(dds, blind = FALSE)
DESeq2::plotPCA(rld, intgroup="group", ntop = 1000)


################################## Running DGE analysis ###############################
###### Set analysis output object
results.full <- list()
# edgeR - classic
results.full["edgeR_exact"]            <- list(runedgeR_exact(count.dat=counts, conditions=group,
                                                              colors=colors,path=outputpath))
# edgeR - glm
results.full["edgeR_glm"]              <- list(runedgeR_glm(count.dat=counts, conditions=group,
                                                            colors=colors,path=outputpath))
# edgeR - robust with prior degree of freedom 10
results.full["edgeR_rob_pDF10"]        <- list(runedgeR_rob_pDF10(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))
# edgeR - robust with prior degree of freedom 5
results.full["edgeR_rob_pDF05"]        <- list(runedgeR_rob_pDF05(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))
# edgeR - robust with prior degree of freedom 15
results.full["edgeR_rob_pDF20"]        <- list(runedgeR_rob_pDF20(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))
# edgeR - robust with prior degree of freedom 15
results.full["edgeR_rob_auto.pDF"]        <- list(runedgeR_rob_auto.pDF(count.dat=counts, conditions=group,
                                                                        colors=colors,path=outputpath))

# edgeR - quasi-likelihood 
results.full["edgeR_ql"]               <- list(runedgeR_ql(count.dat=counts, conditions=group,
                                                           colors=colors,path=outputpath))

# DESeq
results.full["DESeq"]                  <- list(runDESeq(count.dat=counts, conditions=group,
                                                        colors=colors,path=outputpath))

# DESeq2 -- independent.filtering=FALSE, Cook's cut= TRUE
results.full["DESeq2_indFilterDeactive"] <- list(runDESeq2_indFilterDeactive(count.dat=counts, conditions=group,
                                                                             colors=colors,path=outputpath))
# DESeq2 -- independent.filtering=FALSE, Cook's cut= FALSE
results.full["DESeq2_indFilterDeactiveCooksOff"] <- list(runDESeq2_indFilterDeactiveCooksOff(count.dat=counts, conditions=group,
                                                                                             colors=colors,path=outputpath))
# DESeq2 --Default-- independent.filtering=TRUE, Cook's cut= TRUE
results.full["DESeq2_indFilterActive"] <- list(runDESeq2_indFilterActive(count.dat=counts, conditions=group,
                                                                         colors=colors,path=outputpath))


# Limma + quantile normalization
results.full["LimmaQN"]               <- list(runLimmaQN(count.dat=counts, conditions=group,
                                                         colors=colors,path=outputpath))
# LimmaVoom with LSE estimation
results.full["LimmaVoom"]             <- list(runLimmaVoom(count.dat=counts, conditions=group,
                                                           colors=colors,path=outputpath))
# LimmaVoom with robust estimation
results.full["LimmaVoom_Robust"]      <- list(runLimmaVoom_Robust(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))

# LimmaTrended with LSE estimation
results.full["LimmaTrended"]          <- list(runLimmaTrended(count.dat=counts, conditions=group,
                                                              colors=colors,path=outputpath))
# LimmaTrended with robust estimation
results.full["LimmaTrended_Robust"]   <- list(runLimmaTrended_Robust(count.dat=counts, conditions=group,
                                                                     colors=colors,path=outputpath))

# LimmaVoom (with quality weights)
results.full["LimmaVoom_QW"]          <- list(runLimmaVoom_QW(count.dat=counts, conditions=group,
                                                              colors=colors,path=outputpath))
# LimmaVst 
results.full["LimmaVst"]              <- list(runLimmaVst(count.dat=counts, conditions=group,
                                                          colors=colors,path=outputpath))


# BaySeq
results.full["BaySeq"]               <- list(runBaySeq(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))


# PoissonSeq -> Note: pass adapted cut-off to method if required
results.full["PoissonSeq"]            <- list(runPoissonSeq(count.dat=counts, conditions=group,
                                                            colors=colors,path=outputpath))

# SAMSeq
results.full["SAMSeq"]               <- list(runSAMSeq(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))


# QuasiSeq: QL
results.full["QuasiSeq_QL"]          <- list(runQuasiSeq_QL(count.dat=counts, conditions=group,
                                                            colors=colors,path=outputpath))
# QuasiSeq: QLShrink
results.full["QuasiSeq_QLShrink"]    <- list(runQuasiSeq_QLShrink(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))
# QuasiSeq: QLSpline
results.full["QuasiSeq_QLSpline"]    <- list(runQuasiSeq_QLSpline(count.dat=counts, conditions=group,
                                                                  colors=colors,path=outputpath))

#NOISeq
results.full["NOISeq"]               <- list(runNOISeq(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))


#Saving result
saveRDS(results.full, file="result_full_CRC_AZA.RData")



############################## Concordance Analysis between DE tools ########################
#Loading saved result of CRC AZA analysis
results.full <- readRDS("result_full_CRC_AZA.RData") 
results.full["SAMSeq"] <- list(runSAMSeq(count.dat=counts, conditions=group,
                                         colors=colors,path=outputpath))
saveRDS(results.full, file="revised01/result_full_CRC_AZA.RData") 
methods <- names(results.full)

## organaizing results
library(DESeq)
cds <- DESeq::newCountDataSet(counts, group)
cds <- DESeq::estimateSizeFactors(cds)
norm.counts <- counts(cds, normalized=TRUE)

classical.LFC.estimates <- data.frame(classical.LFC = apply(norm.counts, 1, function(x) {
  mu.g1 <- mean(x[group==levels(group)[1]])
  mu.g2 <- mean(x[group==levels(group)[2]])
  if(mu.g1 != 0 & mu.g2 != 0) {lfc <- log2(mu.g2/mu.g1)}
  else if(mu.g1 != 0 & mu.g2 == 0) {lfc <- -log2(mu.g1)}
  else if(mu.g1 == 0 & mu.g2 != 0) {lfc <- log2(mu.g2)}
  return(lfc) }))
classical.LFC.estimates$ID <- rownames(classical.LFC.estimates)

Merge.DE.results <- function(results.full, na.treat ="keep"){
  #A function that returns the rank of genes for all methods 
  methods <-  names(results.full)
  
  df1 <- results.full[1][[paste(methods[1])]]$summary
  df1 <- merge(df1, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
  df1$pval[is.na(df1$pval)] <- 1
  df1$signed.pval <- sign(df1$classical.LFC)*(df1$pval+1e-5)  #A constant +1e-5 is added to each pvalues to avoid 0 signed p-value when p-value is 0
  df1$pi.score <- abs(df1$classical.LFC)*(-log10(df1$pval+1e-5))
  
  df2 <- results.full[2][[paste(methods[2])]]$summary
  df2 <- merge(df2, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
  df2$pval[is.na(df2$pval)] <- 1
  df2$signed.pval <- sign(df2$classical.LFC)*(df2$pval+1e-5)
  df2$pi.score <- abs(df2$classical.LFC)*(-log10(df2$pval+1e-5))
  
  
  summary.all <- merge(df1, df2, by ="ID", all.x=T, all.y=T)
  colnames(summary.all) <- c("ID", paste(methods[1],".", c(colnames(df1)), sep="")[-1], 
                             paste(methods[2],".", c(colnames(df2)), sep="")[-1])
  
  for(i in 3:length(methods)){
    df.i <- results.full[i][[paste(methods[i])]]$summary
    df.i <- merge(df.i, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df.i$pval[is.na(df.i$pval)] <- 1
    
    if(methods[i] !="SAMSeq"){
      df.i$signed.pval <- sign(df.i$classical.LFC)*(df.i$pval+1e-5)
      df.i$pi.score    <- abs(df.i$classical.LFC)*(-log10(df.i$pval+1e-5))
    } 
    else if(methods[i] == "SAMSeq"){
      df.i$stat[is.na(df.i$stat)] <- 0
      df.i$signed.pval <- sign(df.i$classical.LFC)*(1/abs(df.i$stat+1e-5))
      df.i$pi.score    <- abs(df.i$classical.LFC)*(-log10(1/abs(df.i$stat+1e-5)))
    }
    colnames(df.i) <- c("ID", paste(methods[i], ".", colnames(df.i), sep="")[-1])
    
    summary.all <- merge(summary.all, df.i, by ="ID", all.x=T, all.y=T)
    #colnames(summary.all) <- c("ID", methods[1:i])
    print(methods[i])
  }
  
  rownames(summary.all) <- summary.all$ID
  summary.all <- summary.all[,-1]
  
  return(summary.all)
}


#Merging summary results of all the methods
summary.all <- Merge.DE.results(results.full)
dim(summary.all)

methods.name <- c("edgeR exact", "edgeR GLM", "edgeR robust (pDF=10)", "edgeR robust (pDF=5)", 
                  "edgeR robust (pDF=20)", "edgeR robust (pDF=auto)", "edgeR QL",  "DESeq", 
                  "DESeq2 (indFilt=OFF)", "DESeq2 (indFilt=OFF, CooksCut=OFF)", "DESeq2 (indFilt=ON)",
                  "limmaQN", "limmaVoom", "limmaVoom (robust)", 
                  "limmaTrended", "limmaTrended (robust)", "limmaVoom + QW", "limmaVst", 
                  "baySeq", "PoissonSeq", "SAMSeq", 
                  "QuasiSeq (QL)", "QuasiSeq (QLShrink)", "QuasiSeq (QLSpline)",
                  "NOISeq")



#------------------------------------------------------------------------#
#GENE RANK ANALYSIS 
#Spearman's Rank Correlation Matrix
#columns <- paste(methods,".", "signed.pval", sep="")
columns <- paste(methods,".", "pi.score", sep="")
score.matrix <- summary.all[,c(columns)]
colnames(score.matrix) <- methods.name

#classical LFC estimates
columns <- paste(methods,".", "classical.LFC", sep="")
LFC.matrix <- summary.all[,c(columns)]
colnames(LFC.matrix) <- methods.name
LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
rownames(LFC.matrix) <- rownames(summary.all)


#subsetting the top commonly identifed SDE genes across methods
columns <- paste(methods,".", "padj", sep="")
padj.matrix <- summary.all[,c(columns)]
padj.matrix[is.na(padj.matrix)] = 1   #replacing NA values by 1
colnames(padj.matrix) <- methods.name

common.SDE.genes <- names(which(apply(padj.matrix, 1, function(x) {
  if(max(x) < 1) {return(1)}
  else {return(0)}}) == 1))
length(common.SDE.genes)

#Rank correlation, ranks scores and if there are ties, it uses auxillary information to break ties
rank.cov <- function(y, x=NULL, na.last=TRUE, ties.method="average"){
  r <- y
  if(is.null(x)) {r <- rank(y, na.last=na.last, ties.method=ties.method)}
  else if(!is.null(x)){
    r.temp <- rank(y, na.last=na.last, ties.method="min")
    t.r <- table(r.temp)
    ties <- as.numeric(names(which(t.r>1)))
    if(length(ties)>=1) {
      for(i in 1:length(ties)){
        r.cov <- rank(x[r.temp==ties[i]])-1
        r.temp[r.temp==ties[i]] <- r.temp[r.temp==ties[i]] + r.cov
      }
    }
    else{
      r.temp <- rank(y, na.last=na.last, ties.method=ties.method)
    }
    r <- r.temp 
  }
  return(r)
}

rank.matrix <- apply(score.matrix[common.SDE.genes, ], 2, function(v){
  rank.cov(v, x=LFC.matrix[common.SDE.genes, 1])
})


cor.rank <- round(cor(rank.matrix, use = "pairwise.complete.obs", method ="spearman"), 3)
cor.rank.2 <- cor.rank
diag(cor.rank.2) <- NA
mean.cor <- apply(cor.rank.2, 1, function(x) mean(x, na.rm=T))
saveRDS(mean.cor, "mean.rank.cor.RData")

cor.rank[lower.tri(cor.rank, diag = T)] <- NA
cor.rank



library(corrplot)
library(RColorBrewer)

win.graph()
par(mfrow=c(1,2))
par(mar=c(4,4, 4,4)+0.35)
layout(matrix(c(1,1,2), nrow = 1, ncol = 3, byrow = TRUE))

cor.rank.full <- round(cor(rank.matrix, use = "pairwise.complete.obs", method ="spearman"), 3)
corrplot(cor.rank.full, type = "lower", order = "hclust", tl.srt = 20, cl.lim = c(0.75, 1),
         is.corr = FALSE, col =  brewer.pal(n = 5, name = "Spectral"), diag = FALSE,
         title ="pairwise Spearman's rank correlation coefficients", cex.lab=1.25, mar=c(3,3, 3,3))


par(mar=c(4,15, 4, 4)+0.05)
plot(sort(mean.cor, decreasing = TRUE), 1:25, pch=20, cex=2, col="blue", cex.lab=1.25,
     las=1, xlim = c(0.75, 1), axes=FALSE, ylab="", xlab="correlation",
     main="mean Spearman's rank correlation coefficient")
axis(1, seq(0.75, 1, 0.05), col="gray", lwd=2)
axis(2, at=1:25, names(sort(mean.cor, decreasing = TRUE)), col="gray", lwd=2, las=1)
segments(rep(0, 25), 1:25, sort(mean.cor, decreasing = TRUE), 1:25, col="gray")
par(mar=c(4,4, 4, 4)+0.1)


#------------------------------------------------------------------------#
#ANALYSIS OF NUMBER OF DE GENES and CLLASSIFICATION OVERLAPPING
columns <- paste(methods,".", "padj", sep="")
padj.matrix <- summary.all[,c(columns)]
colnames(padj.matrix) <- methods

DE.indicator <- padj.matrix
for(i in 1:nrow(padj.matrix)){
  for(j in 1:ncol(padj.matrix)){
    if(padj.matrix[i,j] < 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 1
    else if(padj.matrix[i,j] >= 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 0
  }
}

avgExp <- rowMeans(norm.counts)
q <- quantile(avgExp, prob=c(0.25, 0.5, 0.75))
q
#     25%        50%        75% 
#75.82372  655.18931 2180.98249

avgExp.cat <- NULL
avgExp.cat[avgExp<=q[1]] <- "Q1"
avgExp.cat[avgExp>q[1] & avgExp<=q[2]] <- "Q2"
avgExp.cat[avgExp>q[2] & avgExp<=q[3]] <- "Q3"
avgExp.cat[avgExp>q[3]] <- "Q4"
avgExp.cat[is.na(avgExp)] <- NA

library(reshape)
DE.indicator2 <- melt(DE.indicator)
DE.indicator2 <- data.frame(DE.indicator2, avgExp.cat =rep(avgExp.cat, times=length(methods)))
colnames(DE.indicator2) <- c("Methods", "DE", "GE.Category")


library(ggplot2)
library(gridExtra)

agr <- aggregate(DE~Methods+GE.Category, data=DE.indicator2, FUN=sum)
agr.all <- aggregate(DE~Methods, data=DE.indicator2, FUN=sum)
agr.all$Methods <- agr$Methods <- methods.name
saveRDS(list(agr.all=agr.all, agr=agr), "SDE.summary.RData")

win.graph()

pl1 <- ggplot(agr[order(agr$GE.Category, decreasing = F),], 
              aes(x=reorder(Methods, DE), y=DE, fill=GE.Category)) + 
  geom_bar(stat="identity", position = "stack")+ 
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
        legend.position=c(0.1, 0.8)) + 
  scale_x_discrete(breaks=methods.name, labels=methods.name)+
  labs(title="A", x="", y="mumber of SDE genes (at 5% FDR)",
       fill="Quartiles")

pl2 <- ggplot(agr,  aes(x=Methods, y=DE, fill=GE.Category)) + 
  geom_bar(stat="identity", position = "fill")+
  theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position='none') + 
  scale_x_discrete(breaks=methods.name, labels=methods.name)+
  labs(title="B", x="", y="proportion")
grid.arrange(pl1, pl2, ncol=2)

#Overlapping of DE classification
overlap <- matrix(NA, ncol=length(methods), nrow=length(methods))
for(i in 1:nrow(overlap)){
  for(j in 1:ncol(overlap)){
    overlap[i,j] <- length(which(DE.indicator[,i]==1 & DE.indicator[,j]==1))
  }
}
colnames(overlap) <- methods
rownames(overlap) <- methods

non.overlap.A <- matrix(NA, ncol=length(methods), nrow=length(methods))
for(i in 1:nrow(non.overlap.A)){
  for(j in 1:ncol(non.overlap.A)){
    non.overlap.A[i,j] <- length(which(DE.indicator[,i]==1 & DE.indicator[,j]==0))
  }
}
colnames(non.overlap.A) <- methods
rownames(non.overlap.A) <- methods

non.overlap.B <- matrix(NA, ncol=length(methods), nrow=length(methods))
for(i in 1:nrow(non.overlap.B)){
  for(j in 1:ncol(non.overlap.B)){
    non.overlap.B[i,j] <- length(which(DE.indicator[,i]==0 & DE.indicator[,j]==1))
  }
}
colnames(non.overlap.B) <- methods
rownames(non.overlap.B) <- methods

overlap.prop <-overlap/(non.overlap.A+overlap+non.overlap.B)
rownames(overlap.prop) <- methods.name
colnames(overlap.prop) <- methods.name

# number_of.SDE <- diag(overlap)
# base <- overlap
# for(i in 1:nrow(base)){
#   for(j in 1:ncol(base)){
#     base[i,j] <- min(number_of.SDE[i], number_of.SDE[j])
#   }
# }
# overlap.prop <- overlap/base
# rownames(overlap.prop) <- methods.name
# colnames(overlap.prop) <- methods.name

overlap.prop.2 <- overlap.prop
diag(overlap.prop.2) <- NA
mean.overlap <- apply(overlap.prop.2, 1, function(x) mean(x, na.rm=T))
saveRDS(mean.overlap, "mean.overlap.prop.RData")




library(corrplot)
library(RColorBrewer)


win.graph()
par(mfrow=c(1,2))
par(mar=c(4,4, 4,4)+0.35)
layout(matrix(c(1,1,2), nrow = 1, ncol = 3, byrow = TRUE))

overlap.prop.full <-overlap/(non.overlap.A+overlap+non.overlap.B)
rownames(overlap.prop.full) <- methods.name
colnames(overlap.prop.full) <- methods.name
corrplot(overlap.prop.full, type = "lower", order = "hclust", tl.srt = 20, cl.lim = c(0, 1),
         is.corr = FALSE, col =  brewer.pal(n = 10, name = "Spectral"), diag = FALSE,
         title ="pairwise proportion of overlap", cex.lab=1.25, mar=c(3,3, 3,3))


par(mar=c(4,15, 4, 4)+0.05)
plot(sort(mean.overlap, decreasing = TRUE), 1:25, pch=20, cex=2, col="blue", cex.lab=1.25,
     las=1, xlim = c(0, 1), axes=FALSE, ylab="", xlab="proportion",
     main="mean proportion of overlap")
axis(1, seq(0, 1, 0.25), col="gray", lwd=2)
axis(2, at=1:25, names(sort(mean.overlap, decreasing = TRUE)), col="gray", lwd=2, las=1)
segments(rep(0, 25), 1:25, sort(mean.overlap, decreasing = TRUE), 1:25, col="gray")
par(mar=c(4,4, 4, 4)+0.1)

#------------------------------------------------------------------------#
#ANALYSIS OF LFC
columns <- paste(methods,".", "logFC", sep="")
LFC.matrix <- summary.all[,c(columns)]
colnames(LFC.matrix) <- methods.name
LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
rownames(LFC.matrix) <- rownames(summary.all)

## Correlation b/n LFC estimates from each method
cor.lfc <- cor(LFC.matrix[-21], method ="pearson", use="pairwise.complete.obs")
rownames(cor.lfc) <- colnames(cor.lfc) <-methods.name[-21]
cor.lfc.2 <- cor.lfc
diag(cor.lfc.2) <- NA
mean.cor.lfc <- apply(cor.lfc.2, 1, function(x) mean(x, na.rm=T))
names(mean.cor.lfc) <- methods.name[-21]
saveRDS(mean.cor.lfc, "mean.lfc.cor.RData")


library(corrplot)
library(RColorBrewer)

win.graph()
par(mfrow=c(1,2))
par(mar=c(4,4, 4,4)+0.35)
layout(matrix(c(1,1,2), nrow = 1, ncol = 3, byrow = TRUE))

cor.lfc.full <- cor(LFC.matrix[,-21], method ="pearson", use="pairwise.complete.obs") 
rownames(cor.lfc.full) <- methods.name[-21]
colnames(cor.lfc.full) <- methods.name[-21]
corrplot(cor.lfc.full, type = "lower", order = "hclust", tl.srt = 20, cl.lim = c(0.8, 1),
         is.corr = FALSE, col =  brewer.pal(n = 6, name = "Spectral"), diag = FALSE,
         title ="Pearson correlation coefficients between pairs of LFC estimates", cex.lab=1.25, mar=c(3,3, 3,3))


par(mar=c(4,15, 4, 4)+0.05)
plot(sort(mean.cor.lfc, decreasing = TRUE), 1:24, pch=20, cex=2, col="blue", cex.lab=1.25,
     las=1, xlim = c(0.8, 1), axes=FALSE, ylab="", xlab="correlation",
     main="mean Pearson correlation of LFC estimates")
axis(1, seq(0.8, 1, 0.05), col="gray", lwd=2)
axis(2, at=1:24, names(sort(mean.cor.lfc, decreasing = TRUE)), col="gray", lwd=2, las=1)
segments(rep(0, 24), 1:24, sort(mean.cor.lfc, decreasing = TRUE), 1:24, col="gray")
par(mar=c(4,4, 4, 4)+0.1)


#Scatter plots between LFC estimates of selected DE tools, 
# with partitioning genes into 4 different abundance levels (quartiles)
methods2 <- methods[c(2,3,8,12,18, 19)]
methods.name2 <- methods.name[c(2,3,8,12,18, 19)]
LFC.matrix2 <- LFC.matrix[, c(2,3,8,12,18, 19)]
LFC.matrix2$avgExp.cat <- avgExp.cat
pairs <- t(combn(length(methods2), 2))  [c(2,3,6,7,10,11,12,13,14),]
cols <- c("dodgerblue4", "firebrick4", "goldenrod4", "mediumseagreen")
win.graph()
par(mfrow=c(3,3))
for(i in 1:nrow(pairs)){
  plot(LFC.matrix2[,pairs[i,1]], LFC.matrix2[, pairs[i,2]], type="n", xlab=paste0(methods.name2[pairs[i,1]]), ylab=paste0(methods.name2[pairs[i,2]]),
       xlim=c(-4, 15), ylim=c(-4, 15))
  points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,2]], pch=6, col=cols[1])
  points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,2]], pch=1, col=cols[2])
  points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,2]], pch=0, col=cols[3])
  points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,2]], pch=17, col=cols[4])
  abline(0,1, lty=2, lwd=2)
  legend("topleft", c(paste0("Q1 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,1]], 
                                                     LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                      paste0("Q2 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,1]], 
                                                     LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                      paste0("Q3 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,1]], 
                                                     LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                      paste0("Q4 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,1]], 
                                                     LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")")),
         pch=c(6, 1, 0, 17), col=cols, bty="n", cex=1.5, ncol=2)
}


#-------------------------------------------------------------------#
#MA plots
win.graph()
par(mfrow=c(2,2))

##edgeR_exact
x <- summary.all[,c("edgeR_exact.avgExpr", "edgeR_exact.logFC", "edgeR_exact.padj")]
colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
x$avgExp.cat <- avgExp.cat
plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="edgeR Exact",
     xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
abline(v=q, lty=2, col="darkcyan")
abline(h=c(-1, 1), lty=2, col="darkcyan")
text(c(1E01, 1.5E02, 1E03, 1.5E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")

##DESeq2
x <- summary.all[,c("DESeq2_indFilterDeactive.avgExpr", "DESeq2_indFilterDeactive.logFC", 
                    "DESeq2_indFilterDeactive.padj")]
colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
x$avgExp.cat <- avgExp.cat
plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="DESeq2",
     xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
abline(v=q, lty=2, col="darkcyan")
abline(h=c(-1, 1), lty=2, col="darkcyan")
text(c(1E01, 1.5E02, 1E03, 1.5E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")

##limmaVoom
x <- summary.all[,c("edgeR_classic.avgExpr", "LimmaVoom.logFC", "LimmaVoom.padj")]
colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
x$avgExp.cat <- avgExp.cat
plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="limmaVoom",
     xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
abline(v=q, lty=2, col="darkcyan")
abline(h=c(-1, 1), lty=2, col="darkcyan")
text(c(1E01, 1.5E02, 1E03, 1.5E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")

##PoissonSeq
x <- summary.all[,c("edgeR_classic.avgExpr", "PoissonSeq.logFC", "PoissonSeq.padj")]
colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
x$avgExp.cat <- avgExp.cat
plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="PoissonSeq",
     xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
abline(v=q, lty=2, col="darkcyan")
abline(h=c(-1, 1), lty=2, col="darkcyan")
text(c(1E01, 1.5E02, 1E03, 1.5E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")


#-------------------------------------------------------------------------
#Distribution of raw p-values
columns <- paste(methods,".", "pval", sep="")
pval.matrix <- summary.all[,c(columns)]
colnames(pval.matrix) <- methods.name
pval.matrix <- as.data.frame(lapply(pval.matrix, function(x) replace(x, is.infinite(x),NA)))
rownames(pval.matrix) <- rownames(summary.all)

win.graph()
par(mfrow=c(3, 4)) 
sel.tools <- c(1, 3, 6, 7, 9, 10, 11, 12, 14, 17, 19, 21)
for(i in sel.tools){
  hist(pval.matrix[, i], xlim = c(0, 1), xlab="raw p-values", main = methods.name[i],
       col=rgb(0.53,0.81,0.98, 0.75), cex.lab=1.5, las=1, nclass = 30, probability = TRUE)
}


#-------------------------------------------------------------------------
#Computational time
comput.time <- sapply(results.full, function(x) x$time)[3, ]
names(comput.time) <- methods.name
saveRDS(comput.time, "comput.time.RData")
