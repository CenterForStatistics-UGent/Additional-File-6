
# sim.res.Zhang.0PDE  <- readRDS("performance.results0PDE.RData") 
# sim.res.Zhang.5PDE  <- readRDS("performance.results5PDE.RData") 
# sim.res.Zhang.10PDE <- readRDS("performance.results10PDE.RData") 
# sim.res.Zhang.15PDE <- readRDS("performance.results15PDE.RData") 
# sim.res.Zhang.20PDE <- readRDS("performance.results20PDE.RData") 
# sim.res.Zhang.25PDE <- readRDS("performance.results25PDE.RData") 
# sim.res.Zhang.30PDE <- readRDS("performance.results30PDE.RData") 
# 
# library(plyr) 
# sim.res.Zhang.all <- rbind.fill(sim.res.Zhang.0PDE, sim.res.Zhang.5PDE, sim.res.Zhang.10PDE, sim.res.Zhang.15PDE,
#                            sim.res.Zhang.20PDE, sim.res.Zhang.25PDE, sim.res.Zhang.30PDE)
# saveRDS(sim.res.Zhang.all, "Revised Simulation/performance measures/New/performance.results.all.RData")

sim.res.Zhang.all <- readRDS("performance.results.all.RData")
sim.res.NGP.all   <- readRDS("performance.results.all.RData") #This is from the dierctory of Simulation 2
str(sim.res.Zhang.all)
table(sim.res.Zhang.all$DE.tool)
tools0 <- unique(sim.res.Zhang.all$DE.tool)
tools  <- tools0[c(3,8,9,13,19,20,23,24)]
tools.name <- c("edgeR (robust, pDF=10)", "DESeq", "DESeq2 (setting1)", "limma (Voom)",  "PoissonSeq", 
                "SAMSeq", "QuasiSeq (Spline)", "NOISeq")
cols <- c("black", "red", "blue", "forestgreen", 
          "darkorange3", "yellow3", "deepskyblue", "lightblue4")

#-----------Figure 4 ------------
png("Revised Simulation/plots/Figure4.png", width = 170, height = 190, res = 300, units = "mm")
par(mgp=c(1.5, 0.5, 0), mai=c(0.4, 0.4, 0.45, 0.1), col="gray")
layout(mat = matrix(c(1,2,3, 4, 5, 5), 3, 2, byrow = TRUE), heights = c(1.9/2, 1.9/2,  0.1))
## Simulation 1: Zhang n =20
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (mRNA) \n n=20, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools)){
  lines(tapply(sim.res.Zhang.all$FDR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==20 & sim.res.Zhang.all$prop.DE==0.25], 
               sim.res.Zhang.all$alpha[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==20& sim.res.Zhang.all$prop.DE==0.25], mean),
        tapply(sim.res.Zhang.all$TPR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==20& sim.res.Zhang.all$prop.DE==0.25], 
               sim.res.Zhang.all$alpha[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==20& sim.res.Zhang.all$prop.DE==0.25], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols[i], lwd=2)
  
  points(mean(sim.res.Zhang.all$FDR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] &  sim.res.Zhang.all$rep.size==20 &
                                           sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE==0.25]),
         mean(sim.res.Zhang.all$TPR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] &  sim.res.Zhang.all$rep.size==20 &
                                           sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE==0.25]), 
         pch=19, cex=1.25, col=cols[i])
} 

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (lncRNA) \n n=20, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools)){
  lines(tapply(sim.res.Zhang.all$FDR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==20& sim.res.Zhang.all$prop.DE==0.25], 
               sim.res.Zhang.all$alpha[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==20& sim.res.Zhang.all$prop.DE==0.25], mean),
        tapply(sim.res.Zhang.all$TPR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==20& sim.res.Zhang.all$prop.DE==0.25], 
               sim.res.Zhang.all$alpha[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==20& sim.res.Zhang.all$prop.DE==0.25], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols[i], lwd=2)
  
  points(mean(sim.res.Zhang.all$FDR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] &  sim.res.Zhang.all$rep.size==20 &
                                             sim.res.Zhang.all$alpha==0.05& sim.res.Zhang.all$prop.DE==0.25]),
         mean(sim.res.Zhang.all$TPR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==20 &
                                             sim.res.Zhang.all$alpha==0.05& sim.res.Zhang.all$prop.DE==0.25]), 
         pch=19, cex=1.25, col=cols[i])
} 


## Simulation 1: Zhang n =40
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (mRNA) \n n=40, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools)){
  lines(tapply(sim.res.Zhang.all$FDR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & sim.res.Zhang.all$prop.DE==0.25], 
               sim.res.Zhang.all$alpha[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & sim.res.Zhang.all$prop.DE==0.25], mean),
        tapply(sim.res.Zhang.all$TPR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & sim.res.Zhang.all$prop.DE==0.25], 
               sim.res.Zhang.all$alpha[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & sim.res.Zhang.all$prop.DE==0.25], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols[i], lwd=2)
  
  points(mean(sim.res.Zhang.all$FDR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 &
                                           sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE==0.25]),
         mean(sim.res.Zhang.all$TPR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] &  sim.res.Zhang.all$rep.size==40 &
                                           sim.res.Zhang.all$alpha==0.05& sim.res.Zhang.all$prop.DE==0.25]), 
         pch=19, cex=1.25, col=cols[i])
} 

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (lncRNA) \n n=40, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools)){
  lines(tapply(sim.res.Zhang.all$FDR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & sim.res.Zhang.all$prop.DE==0.25], 
               sim.res.Zhang.all$alpha[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & sim.res.Zhang.all$prop.DE==0.25], mean),
        tapply(sim.res.Zhang.all$TPR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & sim.res.Zhang.all$prop.DE==0.25], 
               sim.res.Zhang.all$alpha[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & sim.res.Zhang.all$prop.DE==0.25], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols[i], lwd=2)
  
  points(mean(sim.res.Zhang.all$FDR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] &  sim.res.Zhang.all$rep.size==40 &
                                             sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE==0.25]),
         mean(sim.res.Zhang.all$TPR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] &  sim.res.Zhang.all$rep.size==40 &
                                             sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE==0.25]), 
         pch=19, cex=1.25, col=cols[i])
} 


par(mgp=c(0, 0, 0),  mar=c(0, 0, 0, 0))
plot(c(0, 1), c(0, 0.01), type = "n", xlab = "", ylab = "", axes = FALSE)
box("plot")
legend(0, 0.01, tools.name, col=cols, pch=19, lty=1, ncol = 4, cex=1.10, 
       bty = "n", text.col=1.0, pt.cex=1.25)
dev.off()


#-------------
sim.res.Zhang.25PDE <- sim.res.Zhang.all[sim.res.Zhang.all$prop.DE==0.25, ]
sim.res.NGP.25PDE   <- sim.res.NGP.all[sim.res.NGP.all$prop.DE==0.25, ]
#------------- edgeR pipelines ---------
tools0 <- unique(sim.res.Zhang.25PDE$DE.tool)
tools.edgeR  <- tools0[1:7]
tools.name.edgeR <- c("edgeR (exact)", "edgeR (GLM)", "edgeR (robust pDF=10)", "edgeR (robust pDF=5)", 
                      "edgeR (robust pDF=20)", "edgeR (robust pDF=auto)", "edgeR (QL)")
library(RColorBrewer)
cols.edgeR <- rainbow(n = length(tools.name.edgeR))

png("Revised Simulation/plots/ZhangNGP_Sim_25PDE_n40_edgeR.png", width = 170, height = 190, res = 300, units = "mm")
par(mgp=c(1.5, 0.5, 0), mai=c(0.4, 0.4, 0.45, 0.1))
layout(mat = matrix(c(1,2,3,4, 5, 5), 3, 2, byrow = TRUE), heights = c(1.85/2, 1.85/2, 0.15))
## Simulation 1: Zhang n =40
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (mRNA) \n n=40, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.edgeR)){
  lines(tapply(sim.res.Zhang.25PDE$FDR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        tapply(sim.res.Zhang.25PDE$TPR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.edgeR[i], lwd=2)
  
  points(mean(sim.res.Zhang.25PDE$FDR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] & 
                                             sim.res.Zhang.25PDE$rep.size==40 &
                                             sim.res.Zhang.25PDE$alpha==0.05]),
         mean(sim.res.Zhang.25PDE$TPR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] & 
                                             sim.res.Zhang.25PDE$rep.size==40 &
                                             sim.res.Zhang.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.edgeR[i])
}

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1:  Zhang (lncRNA) \n n=40, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.edgeR)){
  lines(tapply(sim.res.Zhang.25PDE$FDR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        tapply(sim.res.Zhang.25PDE$TPR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.edgeR[i], lwd=2)
  
  points(mean(sim.res.Zhang.25PDE$FDR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] &  sim.res.Zhang.25PDE$rep.size==40 &
                                               sim.res.Zhang.25PDE$alpha==0.05]),
         mean(sim.res.Zhang.25PDE$TPR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.edgeR[i] &   sim.res.Zhang.25PDE$rep.size==40 &
                                               sim.res.Zhang.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.edgeR[i])
} 

## Simulation 2: NGP nutlin n = 5
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (mRNA) \n n=5, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.edgeR)){
  lines(tapply(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        tapply(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.edgeR[i], lwd=2)
  
  points(mean(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] &  sim.res.NGP.25PDE$rep.size==5 &
                                           sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] &  sim.res.NGP.25PDE$rep.size==5 &
                                           sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.edgeR[i])
}

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2:  NGP nutlin (lncRNA) \n n=5, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.edgeR)){
  lines(tapply(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        tapply(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.edgeR[i], lwd=2)
  
  points(mean(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] &   sim.res.NGP.25PDE$rep.size==5 &
                                             sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.edgeR[i] &  sim.res.NGP.25PDE$rep.size==5 &
                                             sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.edgeR[i])
} 

par(mgp=c(0, 0, 0), mai=c(0, 0.1, 0, 0))
plot(c(0, 1), c(0, 0.01), type = "n", xlab = "", ylab = "", axes = FALSE)
legend("topleft", tools.name.edgeR, col=cols.edgeR, pch=19, lty=1, ncol = 4)

dev.off()

#------------- DESeq2 pipelines -------------
tools0 <- unique(sim.res.Zhang.25PDE$DE.tool)
tools.DESeq2  <- tools0[c(10, 9, 11)]
tools.name.DESeq2 <- c("DESeq2 (indFilt=ON) => default", "DESeq2 (indFilt=OFF) => setting 1", "DESeq2 (indFilt=OFF, CooksCut=OFF)  => setting 2")
library(RColorBrewer)
cols.DESeq2 <- rainbow(n = length(tools.name.DESeq2))

png("Revised Simulation/plots/ZhangNGP_Sim_25PDE_n40_DESeq2.png", width = 170, height = 190, res = 300, units = "mm")
par(mgp=c(1.5, 0.5, 0), mai=c(0.4, 0.4, 0.45, 0.1))
layout(mat = matrix(c(1,2,3,4, 5, 5), 3, 2, byrow = TRUE), heights = c(1.8/2, 1.8/2, 0.2))

## Simulation 1: Zhang n =40
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (mRNA)\n n=40, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.DESeq2)){
  lines(tapply(sim.res.Zhang.25PDE$FDR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        tapply(sim.res.Zhang.25PDE$TPR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.DESeq2[i], lwd=2, lty=i)
  
  points(mean(sim.res.Zhang.25PDE$FDR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] &  sim.res.Zhang.25PDE$rep.size==40 &
                                             sim.res.Zhang.25PDE$alpha==0.05]),
         mean(sim.res.Zhang.25PDE$TPR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] &   sim.res.Zhang.25PDE$rep.size==40 &
                                             sim.res.Zhang.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.DESeq2[i])
} 

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (lncRNA)\n n=40, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.DESeq2)){
  lines(tapply(sim.res.Zhang.25PDE$FDR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        tapply(sim.res.Zhang.25PDE$TPR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.DESeq2[i], lwd=2, lty=i)
  
  points(mean(sim.res.Zhang.25PDE$FDR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==40 &
                                               sim.res.Zhang.25PDE$alpha==0.05]),
         mean(sim.res.Zhang.25PDE$TPR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] &   sim.res.Zhang.25PDE$rep.size==40 &
                                               sim.res.Zhang.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.DESeq2[i])
}

## Simulation 2: NGP n =5
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (mRNA)\n n=5, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.DESeq2)){
  lines(tapply(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        tapply(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.DESeq2[i], lwd=2, lty=i)
  
  points(mean(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] &  sim.res.NGP.25PDE$rep.size==5 &
                                           sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] &   sim.res.NGP.25PDE$rep.size==5 &
                                           sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.DESeq2[i])
} 

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (lncRNA)\n n=5, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.DESeq2)){
  lines(tapply(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        tapply(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.DESeq2[i], lwd=2, lty=i)
  
  points(mean(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==5 &
                                             sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] &   sim.res.NGP.25PDE$rep.size==5 &
                                             sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.DESeq2[i])
} 

par(mgp=c(0, 0, 0), mai=c(0, 0.1, 0, 0))
plot(c(0, 1), c(0, 0.01), type = "n", xlab = "", ylab = "", axes = FALSE)
legend("topleft", tools.name.DESeq2, col=cols.DESeq2, pch=19, lty=1:3, ncol = 1)

dev.off()

#-----
png("Revised Simulation/plots/ZhangNGP_Sim_25PDE_n10n5_DESeq2.png", width = 170, height = 190, res = 300, units = "mm")
par(mgp=c(1.5, 0.5, 0), mai=c(0.4, 0.4, 0.45, 0.1))
layout(mat = matrix(c(1,2,3,4, 5, 5), 3, 2, byrow = TRUE), heights = c(1.8/2, 1.8/2, 0.2))

## Simulation 1: Zhang n =10
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (mRNA)\n n=10, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.DESeq2)){
  lines(tapply(sim.res.Zhang.25PDE$FDR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==10], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==10], mean),
        tapply(sim.res.Zhang.25PDE$TPR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==10], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==10], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.DESeq2[i], lwd=2, lty=i)
  
  points(mean(sim.res.Zhang.25PDE$FDR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] &  sim.res.Zhang.25PDE$rep.size==10 &
                                             sim.res.Zhang.25PDE$alpha==0.05]),
         mean(sim.res.Zhang.25PDE$TPR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] &   sim.res.Zhang.25PDE$rep.size==10 &
                                             sim.res.Zhang.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.DESeq2[i])
} 

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (lncRNA)\n n=10, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.DESeq2)){
  lines(tapply(sim.res.Zhang.25PDE$FDR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==10], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==10], mean),
        tapply(sim.res.Zhang.25PDE$TPR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==10], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==10], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.DESeq2[i], lwd=2, lty=i)
  
  points(mean(sim.res.Zhang.25PDE$FDR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] & sim.res.Zhang.25PDE$rep.size==10 &
                                               sim.res.Zhang.25PDE$alpha==0.05]),
         mean(sim.res.Zhang.25PDE$TPR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.DESeq2[i] &   sim.res.Zhang.25PDE$rep.size==10 &
                                               sim.res.Zhang.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.DESeq2[i])
}

## Simulation 2: NGP n =3
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (mRNA)\n n=3, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.DESeq2)){
  lines(tapply(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==3], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==3], mean),
        tapply(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==3], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==3], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.DESeq2[i], lwd=2, lty=i)
  
  points(mean(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] &  sim.res.NGP.25PDE$rep.size==3 &
                                           sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] &   sim.res.NGP.25PDE$rep.size==3 &
                                           sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.DESeq2[i])
} 

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (lncRNA)\n n=3, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.DESeq2)){
  lines(tapply(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==3], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==3], mean),
        tapply(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==3], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==3], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.DESeq2[i], lwd=2, lty=i)
  
  points(mean(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] & sim.res.NGP.25PDE$rep.size==3 &
                                             sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.DESeq2[i] &   sim.res.NGP.25PDE$rep.size==3 &
                                             sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.DESeq2[i])
} 

par(mgp=c(0, 0, 0), mai=c(0, 0.1, 0, 0))
plot(c(0, 1), c(0, 0.01), type = "n", xlab = "", ylab = "", axes = FALSE)
legend("topleft", tools.name.DESeq2, col=cols.DESeq2, pch=19, lty=1:3, ncol = 1)

dev.off() 

#------------- limma pipelines ---------
tools0 <- unique(sim.res.Zhang.25PDE$DE.tool)
tools.limma  <- tools0[12:18]
tools.name.limma <- c("limmaQN", "limma (voom)", "limma (voom robust)", "limma (trended)", 
                      "limma (trended robust)", "limma (voom + QW)", "limmaVST")
library(RColorBrewer)
cols.limma <- rainbow(n = length(tools.name.limma))

png("Revised Simulation/plots/ZhangNGP_Sim_25PDE_n40_limma.png", width = 170, height = 190, res = 300, units = "mm")
par(mgp=c(1.5, 0.5, 0), mai=c(0.4, 0.4, 0.45, 0.1))
layout(mat = matrix(c(1,2,3,4, 5, 5), 3, 2, byrow = TRUE), heights = c(1.8/2, 1.8/2, 0.2))

## Simulation 1: Zhang n =40
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (mRNA)\n n=40, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.limma)){
  lines(tapply(sim.res.Zhang.25PDE$FDR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        tapply(sim.res.Zhang.25PDE$TPR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.limma[i], lwd=2)
  
  points(mean(sim.res.Zhang.25PDE$FDR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & 
                                             sim.res.Zhang.25PDE$rep.size==40 &
                                             sim.res.Zhang.25PDE$alpha==0.05]),
         mean(sim.res.Zhang.25PDE$TPR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & 
                                             sim.res.Zhang.25PDE$rep.size==40 &
                                             sim.res.Zhang.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.limma[i])
} 

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (lncRNA)\n n=40, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.limma)){
  lines(tapply(sim.res.Zhang.25PDE$FDR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        tapply(sim.res.Zhang.25PDE$TPR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.limma[i], lwd=2)
  
  points(mean(sim.res.Zhang.25PDE$FDR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & 
                                               sim.res.Zhang.25PDE$rep.size==40 &
                                               sim.res.Zhang.25PDE$alpha==0.05]),
         mean(sim.res.Zhang.25PDE$TPR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.limma[i] & 
                                               sim.res.Zhang.25PDE$rep.size==40 &
                                               sim.res.Zhang.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.limma[i])
} 

## Simulation 2: NGP nutlin n =5
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (mRNA)\n n=5, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.limma)){
  lines(tapply(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.limma[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.limma[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        tapply(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.limma[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.limma[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.limma[i], lwd=2)
  
  points(mean(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.limma[i] &  sim.res.NGP.25PDE$rep.size==5 &
                                           sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.limma[i] &  sim.res.NGP.25PDE$rep.size==5 &
                                           sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.limma[i])
} 

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (lncRNA)\n n=5, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.limma)){
  lines(tapply(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.limma[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.limma[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        tapply(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.limma[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.limma[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.limma[i], lwd=2)
  
  points(mean(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.limma[i] &  sim.res.NGP.25PDE$rep.size==5 &
                                             sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.limma[i] &  sim.res.NGP.25PDE$rep.size==5 &
                                             sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.limma[i])
} 

par(mgp=c(0, 0, 0), mai=c(0, 0.1, 0, 0))
plot(c(0, 1), c(0, 0.01), type = "n", xlab = "", ylab = "", axes = FALSE)
legend("topleft", tools.name.limma, col=cols.limma, pch=19, lty=1, ncol = 4)

dev.off()


#------------- QuasiSeq pipelines ---------
tools0 <- unique(sim.res.Zhang.25PDE$DE.tool)
tools.QuasiSeq  <- tools0[21:23]
tools.name.QuasiSeq <- c("QuasiSeq (QL)", "QuasiSeq (QLShrink)", "QuasiSeq (QLSPline)")
library(RColorBrewer)
cols.QuasiSeq <- rainbow(n = length(tools.name.QuasiSeq))

png("Revised Simulation/plots/ZhangNGP_Sim_25PDE_n40_QuasiSeq.png", width = 170, height = 190, res = 300, units = "mm")
par(mgp=c(1.5, 0.5, 0), mai=c(0.4, 0.4, 0.45, 0.1))
layout(mat = matrix(c(1,2,3,4, 5, 5), 3, 2, byrow = TRUE), heights = c(1.9/2, 1.9/2, 0.1))

## Simulation 1: Zhang n =40
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (mRNA)\n n=40, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.QuasiSeq)){
  lines(tapply(sim.res.Zhang.25PDE$FDR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        tapply(sim.res.Zhang.25PDE$TPR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.QuasiSeq[i], lwd=2, lty=i)
  
  points(mean(sim.res.Zhang.25PDE$FDR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & 
                                             sim.res.Zhang.25PDE$rep.size==40 &
                                             sim.res.Zhang.25PDE$alpha==0.05]),
         mean(sim.res.Zhang.25PDE$TPR.mRNA[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & 
                                             sim.res.Zhang.25PDE$rep.size==40 &
                                             sim.res.Zhang.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.QuasiSeq[i])
} 

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (lncRNA)\n n=40, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.QuasiSeq)){
  lines(tapply(sim.res.Zhang.25PDE$FDR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        tapply(sim.res.Zhang.25PDE$TPR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.Zhang.25PDE$rep.size==40], 
               sim.res.Zhang.25PDE$alpha[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.Zhang.25PDE$rep.size==40], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.QuasiSeq[i], lwd=2, lty=i)
  
  points(mean(sim.res.Zhang.25PDE$FDR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & 
                                               sim.res.Zhang.25PDE$rep.size==40 &
                                               sim.res.Zhang.25PDE$alpha==0.05]),
         mean(sim.res.Zhang.25PDE$TPR.lncRNA[sim.res.Zhang.25PDE$DE.tool==tools.QuasiSeq[i] & 
                                               sim.res.Zhang.25PDE$rep.size==40 &
                                               sim.res.Zhang.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.QuasiSeq[i])
} 

## Simulation 2: NGP nutlin n =5
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (mRNA)\n n=5, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.QuasiSeq)){
  lines(tapply(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        tapply(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.QuasiSeq[i], lwd=2, lty=i)
  
  points(mean(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.NGP.25PDE$rep.size==5 &
                                           sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] &  sim.res.NGP.25PDE$rep.size==5 &
                                           sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.QuasiSeq[i])
} 

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (lncRNA)\n n=5, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools.QuasiSeq)){
  lines(tapply(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        tapply(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols.QuasiSeq[i], lwd=2, lty=i)
  
  points(mean(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] &  sim.res.NGP.25PDE$rep.size==5 &
                                             sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools.QuasiSeq[i] &  sim.res.NGP.25PDE$rep.size==5 &
                                             sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols.QuasiSeq[i])
} 

par(mgp=c(0, 0, 0), mai=c(0, 0.1, 0, 0))
plot(c(0, 1), c(0, 0.005), type = "n", xlab = "", ylab = "", axes = FALSE)
legend("topleft", tools.name.QuasiSeq, col=cols.QuasiSeq, pch=19, lty=1:3, ncol = 3)

dev.off()




#------- performance at different number of replicates ---------
# TPR and FDR at different number of samples per group, pDE=25%, FDR threshold =5%
png("Revised Simulation/plots/ZhangSim_byn_25PDE.png", width = 170, height = 190, res = 300, units = "mm")
par(mgp=c(1.5, 0.5, 0.1), mai=c(0.4, 0.4, 0.45, 0.1), col="gray")
layout(mat = matrix(c(1,2,3, 4, 5, 5), 3, 2, byrow = TRUE), heights = c(1.9/2, 1.9/2,  0.1))

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="number of replicates", ylab = "            FDR", type = "n", las=1,
     main = "Simulation 1: Zhang (mRNA) \n DE proportion = 25%, FDR threshold=5%", xlim = c(2, 40), ylim = c(0, 0.6),
     axes=FALSE)
axis(1, at=unique(sim.res.Zhang.all$rep.size), las=1)
axis(2, at=seq(0, 0.6, 0.1), las=1)
abline(h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.Zhang.all$rep.size), 
        tapply(sim.res.Zhang.all$FDR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$prop.DE == 0.25 & 
                                            sim.res.Zhang.all$alpha==0.05 ], 
               sim.res.Zhang.all$rep.size[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$prop.DE == 0.25 &  
                                           sim.res.Zhang.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="number of replicates", ylab = "            TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (mRNA) \n DE proportion = 25%, FDR threshold=5%", xlim = c(2, 40), ylim = c(0, 0.6),
     axes=FALSE)
axis(1, at=unique(sim.res.Zhang.all$rep.size), las=1)
axis(2, at=seq(0, 0.6, 0.1), las=1)
abline(h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.Zhang.all$rep.size), 
        tapply(sim.res.Zhang.all$TPR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$prop.DE == 0.25 & 
                                            sim.res.Zhang.all$alpha==0.05 ], 
               sim.res.Zhang.all$rep.size[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$prop.DE == 0.25 &  
                                            sim.res.Zhang.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="number of replicates", ylab = "            FDR", type = "n", las=1,
     main = "Simulation 1: Zhang (lncRNA) \n DE proportion = 25%, FDR threshold=5%", xlim = c(2, 40), ylim = c(0, 0.6),
     axes=FALSE)
axis(1, at=unique(sim.res.Zhang.all$rep.size), las=1)
axis(2, at=seq(0, 0.6, 0.1), las=1)
abline(h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.Zhang.all$rep.size), 
        tapply(sim.res.Zhang.all$FDR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$prop.DE == 0.25 & 
                                            sim.res.Zhang.all$alpha==0.05 ], 
               sim.res.Zhang.all$rep.size[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$prop.DE == 0.25 &  
                                            sim.res.Zhang.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="number of replicates", ylab = "            TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (lncRNA) \n DE proportion = 25%, FDR threshold=5%", xlim = c(2, 40), ylim = c(0, 0.6),
     axes=FALSE)
axis(1, at=unique(sim.res.Zhang.all$rep.size), las=1)
axis(2, at=seq(0, 0.6, 0.1), las=1)
abline(h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.Zhang.all$rep.size), 
        tapply(sim.res.Zhang.all$TPR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$prop.DE == 0.25 & 
                                            sim.res.Zhang.all$alpha==0.05 ], 
               sim.res.Zhang.all$rep.size[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$prop.DE == 0.25 &  
                                            sim.res.Zhang.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 

par(mgp=c(0, 0, 0),  mar=c(0, 0, 0, 0))
plot(c(0, 1), c(0, 0.01), type = "n", xlab = "", ylab = "", axes = FALSE)
box("plot")
legend(0, 0.01, tools.name, col=cols, pch=19, lty=1, ncol = 4, cex=1.10, bty = "n", text.col=1.0)
dev.off()

#------- performance at different pDE ---------
# TPR and FDR at different proportion of DE genes, n=40

png("Revised Simulation/plots/ZhangSim_byPDE_n40.png", width = 170, height = 190, res = 300, units = "mm")
par(mgp=c(1.5, 0.5, 0.1), mai=c(0.4, 0.4, 0.45, 0.1), col="gray")
layout(mat = matrix(c(1,2,3, 4, 5, 5), 3, 2, byrow = TRUE), heights = c(1.8/2, 1.8/2,  0.2))

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="proportion of DE genes", ylab = "            FDR", type = "n", las=1,
     main = "Simulation 1: Zhang (mRNA) \n n=40, FDR threshold=5%", xlim = c(0.05, 0.3), ylim = c(0, 0.5))
abline(v=seq(0, 1, 0.05), h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.Zhang.all$prop.DE[sim.res.Zhang.all$prop.DE > 0]), 
        tapply(sim.res.Zhang.all$FDR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & 
                                            sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE > 0], 
               sim.res.Zhang.all$prop.DE[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 &  
                                           sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE > 0], mean),
        type = "o", col=cols[i], lwd=2, xlim = c(0.05, 0.3), ylim = c(0, 0.5))
} 

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="proportion of DE genes", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (mRNA) \n n=40, FDR threshold=5%", xlim = c(0.05, 0.3), ylim = c(0, 0.6))
abline(v=seq(0, 1, 0.05), h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.Zhang.all$prop.DE[sim.res.Zhang.all$prop.DE > 0]), 
        tapply(sim.res.Zhang.all$TPR.mRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 &  
                                            sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE > 0], 
               sim.res.Zhang.all$prop.DE[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & 
                                           sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE > 0], mean),
        type = "o", col=cols[i], lwd=2, xlim = c(0.05, 0.3), ylim = c(0, 0.5))
} 

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="proportion of DE genes", ylab = "            FDR", type = "n", las=1,
     main = "Simulation 1: Zhang (lncRNA) \n n=40, FDR threshold=5%", xlim = c(0.05, 0.3), ylim = c(0, 1))
abline(v=seq(0, 1, 0.05), h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.Zhang.all$prop.DE[sim.res.Zhang.all$prop.DE > 0]), 
        tapply(sim.res.Zhang.all$FDR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & 
                                              sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE > 0], 
               sim.res.Zhang.all$prop.DE[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & 
                                           sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE > 0], mean),
        type = "o", col=cols[i], lwd=2, xlim = c(0.05, 0.3), ylim = c(0, 0.5))
} 

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="proportion of DE genes", ylab = "TPR", type = "n", las=1,
     main = "Simulation 1: Zhang (lncRNA) \n n=40, FDR threshold=5%", xlim = c(0.05, 0.3), ylim = c(0, 0.4))
abline(v=seq(0, 1, 0.05), h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.Zhang.all$prop.DE[sim.res.Zhang.all$prop.DE > 0]), 
        tapply(sim.res.Zhang.all$TPR.lncRNA[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 & 
                                              sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE > 0], 
               sim.res.Zhang.all$prop.DE[sim.res.Zhang.all$DE.tool==tools[i] & sim.res.Zhang.all$rep.size==40 &  
                                           sim.res.Zhang.all$alpha==0.05 & sim.res.Zhang.all$prop.DE > 0], mean),
        type = "o", col=cols[i], lwd=2, xlim = c(0.05, 0.3), ylim = c(0, 0.5))
} 
par(mgp=c(0, 0, 0),  mar=c(0, 0, 0, 0))
plot(c(0, 1), c(0, 0.01), type = "n", xlab = "", ylab = "", axes = FALSE)
box("plot")
legend(0, 0.01, tools.name, col=cols, pch=19, lty=1, ncol = 4, cex=1.10, bty = "n", text.col=1.0)
dev.off()


