
# sim.res.NGP.0PDE  <- readRDS("performance.results0PDE.RData") 
# sim.res.NGP.5PDE  <- readRDS("performance.results5PDE.RData")
# sim.res.NGP.10PDE <- readRDS("performance.results10PDE.RData")
# sim.res.NGP.15PDE <- readRDS("performance.results15PDE.RData")
# sim.res.NGP.20PDE <- readRDS("performance.results20PDE.RData")
# sim.res.NGP.25PDE <- readRDS("performance.results25PDE.RData")
# sim.res.NGP.30PDE <- readRDS("performance.results30PDE.RData")
# 
# library(plyr) 
# sim.res.NGP.all <- rbind.fill(sim.res.NGP.0PDE, sim.res.NGP.5PDE, sim.res.NGP.10PDE, sim.res.NGP.15PDE, 
#                         sim.res.NGP.20PDE, sim.res.NGP.25PDE, sim.res.NGP.30PDE)
# saveRDS(sim.res.NGP.all, "Revised Simulation/performance measures/New/performance.results.all.RData")
sim.res.NGP.all <- readRDS("Revised Simulation/performance measures/New/performance.results.all.RData")

sim.res.NGP.25PDE <- sim.res.NGP.all[sim.res.NGP.all$prop.DE == 0.25,]

str(sim.res.NGP.all)
table(sim.res.NGP.all$DE.tool)
tools0 <- unique(sim.res.NGP.all$DE.tool)
tools  <- tools0[c(3,8,9,13,19,20,23,24)]
tools.name <- c("edgeR (robust, pDF=10)", "DESeq", "DESeq2 (setting1)", "limma (Voom)",  "PoissonSeq", 
                "SAMSeq", "QuasiSeq (Spline)", "NOISeq")
cols <- c("black", "red", "blue", "forestgreen", 
          "darkorange3", "yellow3", "deepskyblue", "lightblue4")

#--------- Figure 5 -------------------------
png("Revised Simulation/plots/Figure5.png", width = 170, height = 95, res = 300, units = "mm")
par(mgp=c(1.5, 0.5, 0), mai=c(0.4, 0.4, 0.45, 0.1), col="gray")
layout(mat = matrix(c(1,2,3, 3), 2, 2, byrow = TRUE), heights = c(1.75,  0.25))
## Simulation 1: NGP n =3
# plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
#      main = "Simulation 2: NGP nutlin (mRNA) \n n=3, DE proportion = 25%", xlim = c(0, 0.5))
# abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
# abline(0, 1, lty=3, col=1)
# for(i in 1:length(tools)){
#   lines(tapply(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==3], 
#                sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==3], mean),
#         tapply(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==3], 
#                sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==3], mean),
#         xlab="FDR", ylab = "TPR", type = "l", col=cols[i], lwd=2)
#   
#   points(mean(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & 
#                                            sim.res.NGP.25PDE$rep.size==3 &
#                                            sim.res.NGP.25PDE$alpha==0.05]),
#          mean(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & 
#                                            sim.res.NGP.25PDE$rep.size==3 &
#                                            sim.res.NGP.25PDE$alpha==0.05]), 
#          pch=19, cex=1.25, col=cols[i])
# } 
# 
# plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
#      main = "Simulation 2: NGP nutlin (lncRNA) \n n=3, DE proportion = 25%", xlim = c(0, 0.5))
# abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
# abline(0, 1, lty=3, col=1)
# for(i in 1:length(tools)){
#   lines(tapply(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==3], 
#                sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==3], mean),
#         tapply(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==3], 
#                sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==3], mean),
#         xlab="FDR", ylab = "TPR", type = "l", col=cols[i], lwd=2)
#   
#   points(mean(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & 
#                                              sim.res.NGP.25PDE$rep.size==3 &
#                                              sim.res.NGP.25PDE$alpha==0.05]),
#          mean(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & 
#                                              sim.res.NGP.25PDE$rep.size==3 &
#                                              sim.res.NGP.25PDE$alpha==0.05]), 
#          pch=19, cex=1.25, col=cols[i])
# } 
# 

## Simulation 1: NGP n =5, alpha=5%
plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (mRNA) \n n=5, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools)){
  lines(tapply(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        tapply(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols[i], lwd=2)
  
  points(mean(sim.res.NGP.25PDE$FDR.mRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & 
                                           sim.res.NGP.25PDE$rep.size==5 &
                                           sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.mRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & 
                                           sim.res.NGP.25PDE$rep.size==5 &
                                           sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols[i])
} 

plot(seq(0, 1, 0.1), seq(0, 1, 0.1), xlab="FDR", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (lncRNA) \n n=5, DE proportion = 25%", xlim = c(0, 0.5))
abline(v=seq(0, 1, 0.1), h=seq(0, 1, 0.1), lty=1, col="gray90")
abline(0, 1, lty=3, col=1)
for(i in 1:length(tools)){
  lines(tapply(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        tapply(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==5], 
               sim.res.NGP.25PDE$alpha[sim.res.NGP.25PDE$DE.tool==tools[i] & sim.res.NGP.25PDE$rep.size==5], mean),
        xlab="FDR", ylab = "TPR", type = "l", col=cols[i], lwd=2)
  
  points(mean(sim.res.NGP.25PDE$FDR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & 
                                             sim.res.NGP.25PDE$rep.size==5 &
                                             sim.res.NGP.25PDE$alpha==0.05]),
         mean(sim.res.NGP.25PDE$TPR.lncRNA[sim.res.NGP.25PDE$DE.tool==tools[i] & 
                                             sim.res.NGP.25PDE$rep.size==5 &
                                             sim.res.NGP.25PDE$alpha==0.05]), 
         pch=19, cex=1.25, col=cols[i])
} 


par(mgp=c(0, 0, 0),  mar=c(0, 0, 0, 0))
plot(c(0, 1), c(0, 0.01), type = "n", xlab = "", ylab = "", axes = FALSE)
box("plot")
legend(0, 0.01, tools.name, col=cols, pch=19, lty=1, ncol = 4, 
       cex=0.85, bty = "n", text.col=1.0,  pt.cex=1.0)
dev.off()

#------TPR and FDR at different proportion of DE genes, n=5 -------
png("Revised Simulation/plots/NGPSim_byPDE_n5.png", width = 170, height = 190, res = 300, units = "mm")
par(mgp=c(1.5, 0.5, 0.1), mai=c(0.4, 0.4, 0.45, 0.1), col="gray")
layout(mat = matrix(c(1,2,3, 4, 5, 5), 3, 2, byrow = TRUE), heights = c(1.8/2, 1.8/2,  0.2))

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="proportion of DE genes", ylab = "            FDR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (mRNA) \n n=5, FDR threshold=5%", xlim = c(0.05, 0.3), ylim = c(0, 0.3))
abline(v=seq(0, 1, 0.05), h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.NGP.all$prop.DE), 
        tapply(sim.res.NGP.all$FDR.mRNA[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$rep.size==5& sim.res.NGP.all$alpha==0.05], 
               sim.res.NGP.all$prop.DE[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$rep.size==5 & sim.res.NGP.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="proportion of DE genes", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (mRNA) \n n=5, FDR threshold=5%", xlim = c(0.05, 0.3), ylim = c(0, 1))
abline(v=seq(0, 1, 0.05), h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.NGP.all$prop.DE), 
        tapply(sim.res.NGP.all$TPR.mRNA[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$rep.size==5& sim.res.NGP.all$alpha==0.05], 
               sim.res.NGP.all$prop.DE[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$rep.size==5 & sim.res.NGP.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="proportion of DE genes", ylab = "            FDR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (lncRNA) \n n=5, FDR threshold=5%", xlim = c(0.05, 0.3), ylim = c(0, 0.3))
abline(v=seq(0, 1, 0.05), h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.NGP.all$prop.DE), 
        tapply(sim.res.NGP.all$FDR.lncRNA[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$rep.size==5& sim.res.NGP.all$alpha==0.05], 
               sim.res.NGP.all$prop.DE[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$rep.size==5 & sim.res.NGP.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 

plot(seq(0, 0.5, 0.1), seq(0, 0.5, 0.1), xlab="proportion of DE genes", ylab = "TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (lncRNA) \n n=5, FDR threshold=5%", xlim = c(0.05, 0.3), ylim = c(0, 1))
abline(v=seq(0, 1, 0.05), h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.NGP.all$prop.DE), 
        tapply(sim.res.NGP.all$TPR.lncRNA[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$rep.size==5& sim.res.NGP.all$alpha==0.05], 
               sim.res.NGP.all$prop.DE[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$rep.size==5 & sim.res.NGP.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 
par(mgp=c(0, 0, 0),  mar=c(0, 0, 0, 0))
plot(c(0, 1), c(0, 0.01), type = "n", xlab = "", ylab = "", axes = FALSE)
box("plot")
legend(0, 0.01, tools.name, col=cols, pch=19, lty=1, ncol = 4, cex=1.10, bty = "n", text.col=1.0)
dev.off()



#--------------TPR and FDR at different number of replicates, pDE=25%, FDR threshold =5% ------------
png("Revised Simulation/plots/NGPSim_byn_25PDE.png", width = 170, height = 190, res = 300, units = "mm")
par(mgp=c(1.5, 0.5, 0.1), mai=c(0.4, 0.4, 0.45, 0.1), col="gray")
layout(mat = matrix(c(1,2,3, 4, 5, 5), 3, 2, byrow = TRUE), heights = c(1.9/2, 1.9/2,  0.1))

plot(c(1:5), seq(0, 1, 0.25), xlab="number of replicates", ylab = " FDR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (mRNA) \n DE proportion = 25%, FDR threshold=5%", xlim = c(2, 5), 
     ylim = c(0, 0.25), axes=FALSE)
axis(1, at=unique(sim.res.NGP.all$rep.size), las=1)
axis(2, at=seq(0, 0.25, 0.05), las=1)
abline(h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.NGP.all$rep.size), 
        tapply(sim.res.NGP.all$FDR.mRNA[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$prop.DE == 0.25 & 
                                          sim.res.NGP.all$alpha==0.05 ], 
               sim.res.NGP.all$rep.size[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$prop.DE == 0.25 &  
                                          sim.res.NGP.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 

plot(c(1:5), seq(0, 1, 0.25), xlab="number of replicates", ylab = " TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (mRNA) \n DE proportion = 25%, FDR threshold=5%", xlim = c(2, 5), 
     ylim = c(0, 1), axes=FALSE)
axis(1, at=unique(sim.res.NGP.all$rep.size), las=1)
axis(2, at=seq(0, 1, 0.2), las=1)
abline(h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.NGP.all$rep.size), 
        tapply(sim.res.NGP.all$TPR.mRNA[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$prop.DE == 0.25 & 
                                          sim.res.NGP.all$alpha==0.05 ], 
               sim.res.NGP.all$rep.size[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$prop.DE == 0.25 &  
                                          sim.res.NGP.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 

plot(c(1:5), seq(0, 1, 0.25), xlab="number of replicates", ylab = " FDR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (lncRNA) \n DE proportion = 25%, FDR threshold=5%", xlim = c(2, 5), 
     ylim = c(0, 0.25), axes=FALSE)
axis(1, at=unique(sim.res.NGP.all$rep.size), las=1)
axis(2, at=seq(0, 0.25, 0.05), las=1)
abline(h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.NGP.all$rep.size), 
        tapply(sim.res.NGP.all$FDR.lncRNA[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$prop.DE == 0.25 & 
                                          sim.res.NGP.all$alpha==0.05 ], 
               sim.res.NGP.all$rep.size[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$prop.DE == 0.25 &  
                                          sim.res.NGP.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 

plot(c(1:5), seq(0, 1, 0.25), xlab="number of replicates", ylab = " TPR", type = "n", las=1,
     main = "Simulation 2: NGP nutlin (lncRNA) \n DE proportion = 25%, FDR threshold=5%", xlim = c(2, 5), 
     ylim = c(0, 1), axes=FALSE)
axis(1, at=unique(sim.res.NGP.all$rep.size), las=1)
axis(2, at=seq(0, 1, 0.2), las=1)
abline(h=seq(0, 1, 0.05), lty=1, col="gray90")

for(i in 1:length(tools)){
  lines(unique(sim.res.NGP.all$rep.size), 
        tapply(sim.res.NGP.all$TPR.lncRNA[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$prop.DE == 0.25 & 
                                          sim.res.NGP.all$alpha==0.05 ], 
               sim.res.NGP.all$rep.size[sim.res.NGP.all$DE.tool==tools[i] & sim.res.NGP.all$prop.DE == 0.25 &  
                                          sim.res.NGP.all$alpha==0.05], mean),
        type = "o", col=cols[i], lwd=2)
} 

par(mgp=c(0, 0, 0),  mar=c(0, 0, 0, 0))
plot(c(0, 1), c(0, 0.01), type = "n", xlab = "", ylab = "", axes = FALSE)
box("plot")
legend(0, 0.01, tools.name, col=cols, pch=19, lty=1, ncol = 4, cex=1.10, bty = "n", text.col=1.0)
dev.off()