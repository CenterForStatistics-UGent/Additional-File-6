library(edgeR) 
library(SimSeq)
library(fdrtool)
library(parallel)

n.itration = 100

setwd(".../Additional File 6/Simulation Study/Simulation 2 (NGP Nutlin)/")

#-------------------------------------------------------------------------------------------
#Loading source dataset
#NGP Nutlin dataset
  counts_celine_NB <- readRDS("celine_neuroblastoma_data.RData")
  counts.source <- counts_celine_NB$counts #19206 genes and 20 samples
  group.source <- counts_celine_NB$group
  
  #biotypes  
  mRNA <- counts_celine_NB$mRNA
  lncRNA <- counts_celine_NB$lncRNA
   
  #proportions
  P.mRNA <- length(mRNA)/nrow(counts.source)
  P.lncRNA <- length(lncRNA)/nrow(counts.source)
  P.mRNA ; P.lncRNA ; P.mRNA + P.lncRNA

  #proportions
  P.mRNA <- length(mRNA)/nrow(counts.source)
  P.lncRNA <- length(lncRNA)/nrow(counts.source)
  P.mRNA ; P.lncRNA ; P.mRNA + P.lncRNA
  
  rm("counts_celine_NB")

#-------------------------------------------------------------------------------------------
#Simulate data  
#Preparation of SimSeq 
lib.sizes <- apply(counts.source, 2, sum)
nf <- calcNormFactors(counts.source) * lib.sizes              #using edgeR package

## Compute weights to sample DE genes in SimData function using edgeR normalization method TMM
probs <- CalcPvalWilcox(counts.source, treatment = group.source, replic = NULL,
                        sort.method = "unpaired", sorted = TRUE, nf, exact = FALSE)

wghts <- 1 - fdrtool(probs, statistic = "pvalue", plot = FALSE, verbose = FALSE)$lfd

saveRDS(list(probs=probs, weights=wghts), file="weights.RData", ascii=TRUE)

#Simulation Parameter setting
PDE <- c(0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3)  #proportion of true DE genes
for(pde in 1:length(PDE)){
print(paste("PDE =", PDE[pde]))

if(pde>1){
	rm(list=names(results))
	rm(list=c("results", "DE.result", "par.list"))
}

n.genes <- 10000
p.diff <- PDE[pde]  #0, 0.01,  0.05, 0.1, 0.2, 0.3
n.initial <- 12000 #number of genes to be simulated before filtration

par.setting <- list(list(counts.sources = counts.source, group.source = group.source, nf=nf, 
                         k.ind = 2, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                    list(counts.sources = counts.source, group.source = group.source, nf=nf,
                         k.ind = 3, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                    list(counts.sources= counts.source, group.source = group.source, nf=nf,
                         k.ind = 4, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                    list(counts.sources= counts.source, group.source = group.source, nf=nf,
                         k.ind = 5, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts))
n.samples <- length(par.setting)
par.list <- rep(par.setting, each=n.itration)

#-------------------------------------------------------------------------
print(paste(".... simulating counts"))

#generating counts
source("SimSeqCode.R")
gene.biotype.source=list(mRNA=mRNA, lncRNA=lncRNA)
sim.counts <- lapply(par.list, FUN=generate.count,  gene.biotype.source=gene.biotype.source)
saveRDS(sim.counts, file=paste0("sim_counts", 100*p.diff, "_small_study_PDE.RData"), ascii =TRUE)


#-------------------------------------------------------------------------
print(paste(".... analysis of simulated counts"))
#Apply DE tools on simulated data

cl <- detectCores()
cl <- makeCluster(cl) 
cl

#Running DE Tool wrap functions
source("DE_Tools.R")


res.edgeR.exact                       = parLapplyLB(cl, sim.counts, run_edgeR_exact)
print(paste("... ... edgeR exact...completed"))
res.edgeR.glm                         = parLapplyLB(cl, sim.counts, run_edgeR_glm)
print(paste("... ... edgeR GLM...completed"))

res.edgeR.robust.10priorDF            = parLapplyLB(cl, sim.counts, run_edgeR_robust_10priorDF)
print(paste("... ... edgeR rob 10pDE...completed"))

res.edgeR.robust.5priorDF             = parLapplyLB(cl, sim.counts, run_edgeR_robust_5priorDF)
print(paste("... ... edgeR rob 5pDE...completed"))

res.edgeR.robust.20priorDF            = parLapplyLB(cl, sim.counts, run_edgeR_robust_20priorDF)
print(paste("... ... edgeR rob 20pDE...completed"))

res.edgeR.robust.auto.priorDF         = parLapplyLB(cl, sim.counts, run_edgeR_robust_auto.priorDF)
print(paste("... ... edgeR rob autopDE...completed"))

res.edgeR.QL                          = parLapplyLB(cl, sim.counts, run_edgeR_ql)
print(paste("... ... edgeR QL...completed"))

res.DESeq                             = parLapplyLB(cl, sim.counts, run_DESeq)
print(paste("... ... DESeq...completed"))

res.DESeq2.indFilterDeactive          = parLapplyLB(cl, sim.counts, run_DESeq2_indFilterDeactive)
print(paste("... ... DESeq2 I ...completed"))

res.DESeq2.indFilterActive            = parLapplyLB(cl, sim.counts, run_DESeq2_indFilterActive)
print(paste("... ... DESeq2 II ...completed"))

res.DESeq2.indFilterDeactive.CooksOff = parLapplyLB(cl, sim.counts, run_DESeq2_indFilterDeactive_CooksOff)
print(paste("... ... DESeq2 III ...completed"))

res.limmaQN                           = parLapplyLB(cl, sim.counts, run_limmaQN)
print(paste("... ... limma QN ...completed"))

res.limmaVoom                         = parLapplyLB(cl, sim.counts, run_limmaVoom)
print(paste("... ... limma voom ...completed"))

res.limmaVoom.robust                  = parLapplyLB(cl, sim.counts, run_limmaVoom_robust)
print(paste("... ... limma voom rob ...completed"))

res.limmaTrended                      = parLapplyLB(cl, sim.counts, run_limmaTrended)
print(paste("... ... limma Trend ...completed"))

res.limmaTrended.robust               = parLapplyLB(cl, sim.counts, run_limmaTrended_robust)
print(paste("... ... limma Trend rob ...completed"))

res.limmavoom_QW                      = parLapplyLB(cl, sim.counts, run_limmaVoom_QW)
print(paste("... ... limma voom + QW ...completed"))

res.limmaVst                          = parLapplyLB(cl, sim.counts, run_limmaVst)
print(paste("... ... limma VST ...completed"))

res.PoissonSeq                        = parLapplyLB(cl, sim.counts, run_PoissonSeq)
print(paste("... ... PoissonSeq ...completed"))

res.SAMSeq                            = parLapplyLB(cl, sim.counts, run_SAMSeq)
print(paste("... ... SAMSeq ...completed"))

res.QuasiSeq                          = parLapplyLB(cl, sim.counts, run_QuasiSeq)
print(paste("... ... QuasiSeq ...completed"))

res.QuasiSeq.QL         = lapply(res.QuasiSeq, function(x) x$QL.res)
res.QuasiSeq.QLShrink   = lapply(res.QuasiSeq, function(x) x$QLShrink.res)
res.QuasiSeq.QLSpline   = lapply(res.QuasiSeq, function(x) x$QLSpline.res)

res.NOSeq                             = parLapplyLB(cl, sim.counts, run_NOISeq)
print(paste("... ... NOiSeq ...completed"))

stopCluster(cl)


results <-list(
res.edgeR.exact                       = res.edgeR.exact,
res.edgeR.glm                         = res.edgeR.glm,
res.edgeR.robust.10priorDF            = res.edgeR.robust.10priorDF,
res.edgeR.robust.5priorDF             = res.edgeR.robust.5priorDF,
res.edgeR.robust.20priorDF            = res.edgeR.robust.20priorDF,
res.edgeR.robust.auto.priorDF         = res.edgeR.robust.auto.priorDF,
res.edgeR.QL                          = res.edgeR.QL,
res.DESeq                             = res.DESeq,
res.DESeq2.indFilterDeactive          = res.DESeq2.indFilterDeactive ,
res.DESeq2.indFilterActive            = res.DESeq2.indFilterActive, 
res.DESeq2.indFilterDeactive.CooksOff = res.DESeq2.indFilterDeactive.CooksOff ,
res.limmaQN                           = res.limmaQN ,
res.limmaVoom                         = res.limmaVoom,
res.limmaVoom.robust                  = res.limmaVoom.robust ,
res.limmaTrended                      = res.limmaTrended,
res.limmaTrended.robust               = res.limmaTrended.robust,
res.limmavoom_QW                      = res.limmavoom_QW,
res.limmaVst                          = res.limmaVst,
res.PoissonSeq                        = res.PoissonSeq,
res.SAMSeq                            = res.SAMSeq,
res.QuasiSeq.QL                       = res.QuasiSeq.QL,
res.QuasiSeq.QLShrink                 = res.QuasiSeq.QLShrink,
res.QuasiSeq.QLSpline                 = res.QuasiSeq.QLSpline,
res.NOSeq                             = res.NOSeq
)

saveRDS(results, file=paste0("DE_result", 100*p.diff, "_small_study_PDE.RData"), ascii =TRUE)

#-------------------------------------------------------------------------
#Compute performance measures
print(paste(".... summarizing analyzed simulated counts"))

perf.metrics.list <- list()
fdr.thrld= seq(0, 1, 0.005)  

  DE.result <- results
  perf.metrics.sub.list <- list()
  for(j in 1:length(fdr.thrld)){
    print(j)
    thrld <- fdr.thrld[j]
    perf.metrics <- lapply(DE.result, function(x){
      t(sapply(x, function(y){
        res <- y$result
        sumr.mRNA <- calc.perf.metrics(res$q[res$biotype=="mRNA"], res$de.genes[res$biotype=="mRNA"], thrld = thrld)
        FNR.mRNA <- sumr.mRNA$FNR
        TPR.mRNA <- sumr.mRNA$TPR
        TNR.mRNA <- sumr.mRNA$TNR
        FPR.mRNA <- sumr.mRNA$FPR
        FDR.mRNA <- sumr.mRNA$FDR
        
        sumr.lncRNA <- calc.perf.metrics(res$q[res$biotype=="lncRNA"], res$de.genes[res$biotype=="lncRNA"], thrld = thrld)
        FNR.lncRNA <- sumr.lncRNA$FNR
        TPR.lncRNA <- sumr.lncRNA$TPR
        TNR.lncRNA <- sumr.lncRNA$TNR
        FPR.lncRNA <- sumr.lncRNA$FPR
        FDR.lncRNA <- sumr.lncRNA$FDR
        
        rep.size <- y$inputs$setting$k.ind
        prop.DE  <- y$inputs$setting$p.diff
        biotype.composition <- unlist(y$inputs$gene.biotype.composition)
        c(FNR.mRNA=FNR.mRNA, TPR.mRNA=TPR.mRNA, TNR.mRNA=TNR.mRNA,FPR.mRNA=FPR.mRNA, 
          FDR.mRNA=FDR.mRNA,
          FNR.lncRNA=FNR.lncRNA, TPR.lncRNA=TPR.lncRNA, TNR.lncRNA=TNR.lncRNA,
          FPR.lncRNA=FPR.lncRNA, FDR.lncRNA=FDR.lncRNA,
          rep.size=rep.size, prop.DE=prop.DE, biotype.composition)
      }))
    })
    perf.metrics2 <- as.data.frame(do.call("rbind", perf.metrics))
    perf.metrics2$DE.tool  <- rep(names(perf.metrics), each=n.itration*n.samples)
    perf.metrics2$alpha    <- thrld
    perf.metrics.sub.list[j] <- list(perf.metrics2)
  }
  perf.metrics.sub.list <- do.call("rbind", perf.metrics.sub.list)
  

saveRDS(perf.metrics.sub.list, paste0("performance.results", 100*p.diff, "_small_study_PDE.RData"), ascii =TRUE)
print(paste(".... done."))
}



