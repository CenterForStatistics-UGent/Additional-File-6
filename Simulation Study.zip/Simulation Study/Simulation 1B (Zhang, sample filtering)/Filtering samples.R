library(scater)
library(edgeR)
library(DESeq2)

setwd("C:/Users/Alemu/Dropbox/Reports/Genome Biology journal/Revised01/Additional Files/Additional File 6/")

#-------------------------------------------------------------------------------------------
#Loading source dataset
#Zhang dataset
counts_Neuroblastoma <- readRDS("Data/Zhang/raw data/counts_Neuroblastoma.RData")
counts.source0 <- counts_Neuroblastoma[[1]]  #33605 genes and 172 samples
group.source0 <- as.factor(counts_Neuroblastoma[[2]])


counts.source <- counts.source0[, c(which(group.source0 == levels(group.source0)[1]),
                                    which(group.source0 == levels(group.source0)[2]))]

group.source  <- group.source0[c(which(group.source0 == levels(group.source0)[1]),
                                    which(group.source0 == levels(group.source0)[2]))]

# flag samples with extreme library size
LS.source <- colSums(counts.source)
table(isOutlier(LS.source, nmads = 3, log = TRUE))
LS.outlier.sample <- colnames(counts.source)[isOutlier(LS.source, nmads = 3, log = TRUE)]

par(mfrow=c(1,2))
hist(log(LS.source), main = "all library sizes")  
hist(log(LS.source[!(names(LS.source) %in% LS.outlier.sample)]), main = "filtered library sizes")  


# flag samples based on the number of genes detected
DS.source <- apply(counts.source, 2, function(x) sum(x>0))
table(isOutlier(DS.source, nmads = 3, log = TRUE))
DS.outlier.sample <- colnames(counts.source)[isOutlier(DS.source, nmads = 3, log = TRUE)]

par(mfrow=c(2,2))
hist(log(DS.source), main = "all samples")  
hist(log(DS.source[!(names(DS.source) %in% DS.outlier.sample)]), main = "filtered samples") 

plot(LS.source, DS.source, log="xy", xlab="all library size", 
     ylab="number of detected genes", col=1, cex=1, pch=20)
points(LS.source[(names(LS.source) %in% LS.outlier.sample)], 
       DS.source[(names(LS.source) %in% LS.outlier.sample)], col="blue", cex=1.35)
points(LS.source[(names(DS.source) %in% DS.outlier.sample)], 
       DS.source[(names(DS.source) %in% DS.outlier.sample)], col="red", cex=1.65)

par(mfrow=c(1,1))

#flag samples with low within group correlation 
calc.cor <- function(count, group){
  group <- as.factor(group)
  
  cor.1 <- cor(count[,group==levels(group)[1]])
  cor.2 <- cor(count[,group==levels(group)[2]])
  
  diag(cor.1) <- NA
  diag(cor.2) <- NA
  
  cor.1 <- rowMeans(cor.1, na.rm = TRUE)
  cor.2 <- rowMeans(cor.2, na.rm = TRUE)
  
  cors <- c(cor.1, cor.2) 
  cors
}
cors <- calc.cor(count=counts.source, group=group.source)
par(mfrow=c(1,1), mar=c(4, 6, 3, 1))
barplot(sort(cors), las=1, horiz = TRUE, ylab="mean correlation with other samples in the same group")

R.outlier.samples <- names(cors[cors<quantile(cors, 0.15)])
length(R.outlier.samples)


# flag samples based on distance matrix
## using DESeq2
counts.source.no_zeros <- counts.source[apply(counts.source, 1, function(x) sum(x==0)<0.5*length(x)), ]
dds <- DESeq2::DESeqDataSetFromMatrix(countData = counts.source.no_zeros, 
                                      colData = DataFrame(group.source), ~group.source)
vsd <- DESeq2::vst(dds, blind=FALSE)
DESeq2::plotPCA(vsd, intgroup=c("group.source"), ntop=nrow(counts.source.no_zeros))
pca <- DESeq2::plotPCA(vsd, intgroup=c("group.source"), ntop=nrow(counts.source.no_zeros),
                returnData=TRUE)

head(pca) ; dim(pca)
apply(pca[, 1:2], 2, function(x) quantile(abs(x), c(0, 0.1, 0.15, 0.25, 0.5, 0.75, 0.85, 0.9, 1)))
PCA.outlier.samples <- pca[(abs(pca$PC1) > 73 | abs(pca$PC2) > 58), ]
dim(PCA.outlier.samples)
PCA.outlier.samples <- rownames(PCA.outlier.samples)

head(pca)
pca$outlier <- ifelse(pca$name %in% PCA.outlier.samples, 1, 0)
pca$cols    <- ifelse(pca$group==0, "orange", "deepskyblue3")
head(pca)

plot(pca$PC1, pca$PC2, pch=19, col=pca$cols, cex=1.25, xlab="PC1: 16%", ylab="PC2: 9%", las=1, 
     ylim=c(-100, 100), xlim=c(-100, 100), cex.lab=1.25)
abline(h=c(-58, 58), v=c(-73, 73), col="gray", lty=3)
points(pca$PC1[pca$outlier==1], pca$PC2[pca$outlier==1], pch=1, col=2, lwd=1.5,  cex=2)
legend("topright", c("MYCN not amplified", "MYCN amplified"), pch=19, col=c("orange", "deepskyblue3"), cex=1.25)



# all outliers
outlier.samples <- unique(c(LS.outlier.sample, DS.outlier.sample, R.outlier.samples, PCA.outlier.samples))
length(outlier.samples)


filtered.counts.source <- counts.source[, which(!(colnames(counts.source) %in% outlier.samples))]
filtered.group.source  <- group.source[which(!(colnames(counts.source) %in% outlier.samples))]
table(filtered.group.source)

# gene filtering
counts.source2 <- counts.source[apply(counts.source, 1, function(x){
  all(tapply(x, group.source, function(y) sum(y>0))>10)
}),]
filtered.counts.source2 <- filtered.counts.source[apply(filtered.counts.source,1, function(x){
  all(tapply(x, filtered.group.source, function(y) sum(y>0))>10)
}),]
dim(counts.source) ; dim(filtered.counts.source)
dim(counts.source2) ; dim(filtered.counts.source2)

#Biotypes
mRNA   <- counts_Neuroblastoma$gene.biotype$Gene_Name[counts_Neuroblastoma$gene.biotype$Gene_Biotype == "protein_coding"]
lncRNA <- counts_Neuroblastoma$gene.biotype$Gene_Name[counts_Neuroblastoma$gene.biotype$Gene_Biotype %in% c("lincRNA", "antisense")]


# compare the BCV between the original and filtered sample
y1 <- DGEList(counts=counts.source2, group=group.source)
y1 <- calcNormFactors(y1)
design1 <- model.matrix(~group.source)
y1 <- estimateDisp(y1,design = design1)

y2 <- DGEList(counts=filtered.counts.source2, group=filtered.group.source)
y2 <- calcNormFactors(y2)
design2 <- model.matrix(~filtered.group.source)
y2 <- estimateDisp(y2, design = design2)

par(mfrow=c(1,2))
plotBCV(y1, main="orginal count",  ylim = c(0, 6))
plotBCV(y2, main="Filtered count", ylim = c(0, 6))

BCV <- list(org.count.mRNA=sqrt(y1$tagwise.dispersion[which(rownames(y1$counts) %in% mRNA)]), 
            filtered.count.mRNA=sqrt(y2$tagwise.dispersion[rownames(y2$counts) %in% mRNA]),
            org.count.lncRNA=sqrt(y1$tagwise.dispersion[rownames(y1$counts) %in% lncRNA]),
            filtered.count.lncRNA=sqrt(y2$tagwise.dispersion[rownames(y2$counts) %in% lncRNA]))

BCV <- data.frame(bcv=c(BCV$org.count.mRNA, BCV$filtered.count.mRNA, 
                        BCV$org.count.lncRNA, BCV$filtered.count.lncRNA),
                  dat = rep(names(BCV), sapply(BCV, length)))

BCV$biotype <- ifelse(BCV$dat %in% c("org.count.mRNA", "filtered.count.mRNA"), "mRNA", "lncRNA")
BCV$data    <- ifelse(BCV$dat %in% c("org.count.mRNA", "org.count.lncRNA"), "unfiltered", "filtered")

head(BCV)
win.graph()
ggplot(BCV, aes(y=bcv, x=data, group=interaction(biotype, data), colour=biotype))+
  geom_violin(trim = TRUE, draw_quantiles=c(0.25, 0.5, 0.75), size=1.5)+
  scale_color_manual(values = c("orange", "deepskyblue3"))+
  labs(x=NULL, y="BCV")+
  theme_bw()+
  theme(axis.text = element_text(size=16, angle = 0),
        axis.title.y = element_text(size = 20),
        legend.position = c(0.2, 0.9),
        legend.text = element_text(size=16),
        legend.title = element_text(size=20))




#Save filtered data

saveRDS(list(counts=filtered.counts.source2, group=filtered.group.source, mRNA=mRNA, lncRNA=lncRNA),
        "Simulation Study/Simulation 1B (Zhang, sample filtering)/filtered.Zhang.data.RData")








